<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\User;
use Auth;
use App\Profile;
use App\Qualification;
use App\Address;
use App\JobRole;
use App\Job;
use App\CandidateApply;
use Storage;
use Session;

class ProfileController extends Controller
{
    public function index(request $request){
    	if(Auth::user()->role=='Candidate' || Auth::user()->role=='Employer'){
        $auth = Auth::user();
        $profile = Profile::where('UserId',$auth->id)->first();
        $address = Address::where('UserId',$auth->id)->first();
        $ql = Qualification::where('UserId',$auth->id)->first();
        $job = JobRole::where('UserId',$auth->id)->first();
    	return view('Profil',compact('profile','address','ql','job'));
    	}
    	else{
    	return redirect()->route('Select-Role');
    	}
    }

    public function select(request $request){
    	if(Auth::user()->role=='Candidate' || Auth::user()->role=='Employer'){
    	return redirect()->route('Profile');
    	}
    	else{
    	return view('Select');
    	}
    }

    public function role_store(request $request){
    	$auth = Auth::user();
    	$user = User::where('id',$auth->id)->first();
    	$user->role = $request->role;
    	$user->save();
    	$request->session()->flash('success','You Are Selected Role. Please Update Your Profile');
    	return redirect()->route('Profile');
    }

    public function logout(){
        Auth::logout();
        return redirect()->route('Index');
    }

    public function store(request $request){
        $auth = Auth::user();
        $check = Profile::where('UserId',$auth->id)->count();
        if($check==0){
        $profile = new Profile();
        }
        else{
        $profile = Profile::where('UserId',$auth->id)->first();
        }
        $profile->Name = $request->Name;
        $profile->Email = $request->Email;
        $profile->Mobile = $request->Mobile;
        $profile->Age = $request->Age;
        $profile->UserId = $request->UserId;
        $profile->Gender = $request->Gender;
        $profile->save();
        $request->session()->flash('success','Profile Updated Success!');
        return redirect()->route('Profile');
    }

    public function address_store(request $request){
        $auth = Auth::user();
        $check = Address::where('UserId',$auth->id)->count();
        if($check==0){
        $profile = new Address();
        }
        else{
        $profile = Address::where('UserId',$auth->id)->first();
        }
        $profile->Address = $request->Address;
        $profile->City = $request->City;
        $profile->State = $request->State;
        $profile->UserId = $request->UserId;
        $profile->PinCode = $request->PinCode;
        $profile->save();
        $request->session()->flash('success','Address Updated Success!');
        return redirect()->route('Profile');
    }

    public function qualification_store(request $request){
        $auth = Auth::user();
        $check = Qualification::where('UserId',$auth->id)->count();
        if($check==0){
        $profile = new Qualification();
        }
        else{
        $profile = Qualification::where('UserId',$auth->id)->first();
        }
        $profile->Language = $request->Language;
        $profile->UserId = $request->UserId;
        $profile->MaxQualification = $request->Qualification;
        $profile->save();
        $request->session()->flash('success','Qualification Updated Success!');
        return redirect()->route('Profile');
    }

    public function job_role_store(request $request){
        $data = implode(",", $request->JobRole);
        $auth = Auth::user();
        $check = JobRole::where('UserId',$auth->id)->count();
        if($check==0){
        $profile = new JobRole();
        }
        else{
        $profile = JobRole::where('UserId',$auth->id)->first();
        }
        $profile->JobRole = $data;
        $profile->UserId = $request->UserId;
        $profile->save();
        $request->session()->flash('success',' You have been signin successfully!');
        return redirect()->route('Profile');
    }

    public function job_post(request $request){
        $auth = Auth::user();
        if($auth->role=='Employer'){
        return view('JobPost');
        }
        else{
            return redirect()->route('Index');
        }
    }

    public function job_store(request $request){
        $data = new Job();
        $data->CompanyName  = $request->CompanyName;
        $data->JobTitle  = $request->JobTitle;
        $data->JobDescription  = $request->JobDescription;
        $data->OfferedSallary  = $request->OfferedSallary;
        $data->JobType  = $request->JobType;
        $data->JobCategory  = $request->JobCategory;
        $data->Experience  = $request->Experience;
        $data->Gender  = $request->Gender;
        $data->Qualification  = $request->Qualification;
        $data->ApplicationDeadLine  = $request->ApplicationDeadLine;
        $data->State  = $request->State;
        $data->City  = $request->City;
        $data->CompleteAddress  = $request->CompleteAddress;
        $data->Email  = $request->Email;
        $data->Date = date('d-m-Y');
        $data->Mobile  = $request->Mobile;
        $data->UserId = Auth::user()->id;
        if($request->hasfile('Logo')){
            $file = $request->file('Logo');
            $name = time().'.'.$file->getClientOriginalExtension();
            $filepath = public_path('assets/uploads');
            $file->move($filepath,$name);
            $data->logo = $name;
        }
        $data->save();
        $request->session()->flash('success',' You have job posted successfully! It will Active in 12 to 24 hours.');
        return redirect()->route('Profile/JobPost/List');
    }


    public function jobupdate(request $request){
        $data =  Job::where('id',$request->Update)->first();
        $data->CompanyName  = $request->CompanyName;
        $data->JobTitle  = $request->JobTitle;
        $data->JobDescription  = $request->JobDescription;
        $data->OfferedSallary  = $request->OfferedSallary;
        $data->JobType  = $request->JobType;
        $data->JobCategory  = $request->JobCategory;
        $data->Experience  = $request->Experience;
        $data->Gender  = $request->Gender;
        $data->Qualification  = $request->Qualification;
        $data->ApplicationDeadLine  = $request->ApplicationDeadLine;
        $data->State  = $request->State;
        $data->City  = $request->City;
        $data->CompleteAddress  = $request->CompleteAddress;
        $data->Email  = $request->Email;
        $data->Mobile  = $request->Mobile;
        if($request->hasfile('Logo')){
            $file = $request->file('Logo');
            $name = time().'.'.$file->getClientOriginalExtension();
            $filepath = public_path('assets/uploads');
            $file->move($filepath,$name);
            $data->logo = $name;
        }
        $data->save();
        $request->session()->flash('success',' You have job updated successfully!');
        return redirect()->route('Profile/JobPost/List');
    }


    public function job_post_list(request $request){
        $data = Job::where('UserId',Auth::user()->id)->orderBy('id','desc')->get();
        return view('PostedJobs',compact('data'));
    }

    public function editsession(request $request){
        Session::put('job_id',$request->Edit);
        return redirect()->route('Profile/Job-Post/Edit');
    }

    public function jobedit(request $request){
         $auth = Auth::user();
        if($auth->role=='Employer'){
        $jobid = Session::get('job_id');
        $edit = Job::where('id',$jobid)->first();
        return view('JobPost',compact('edit'));
        }
        else{
        return redirect()->route('Index');
        }
    }

    public function appliedcandidae(request $request){
        $auth = Auth::user();
        $applied_candidates = User::join('candidate_apply','candidate_apply.CandidateId','users.id')->select('candidate_apply.AppliedEmail','candidate_apply.CandidateId','candidate_apply.AppliedMobile','candidate_apply.JobTitle','candidate_apply.UserId','users.*')->get();
        return view('ApplidCandidates',compact('applied_candidates'));
    }

    public function job_post_delete(request $request){
        Job::where('id',$request->Delete)->delete();
        $request->session()->flash('success',' You have job deleted successfully!');
        return redirect()->route('Profile/JobPost/List');
    }

    
}
