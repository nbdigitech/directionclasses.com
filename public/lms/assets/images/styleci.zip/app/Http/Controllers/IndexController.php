<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Socialite;
use App\User;
use Auth;
use App\Job;
use App\EnquiryForm;

class IndexController extends Controller{
    public function index(){
        $data = Job::where('AdminApprove',1)->limit(6)->orderBy('id','desc')->get();
    	return view('Index',compact('data'));
    }

    public function login(){
    	return redirect()->route('Index');
    }

    public function callback($provider){
    	$getInfo = Socialite::driver($provider)->user();
    	$check = User::where('email',$getInfo->email)->count();
    	if($check==0){
    	$user = new User();
    	$user->name = $getInfo->name;
    	$user->email = $getInfo->email;
    	$user->pic = $getInfo->avatar_original;
    	$user->provider_id = $getInfo->id;
    	$user->provider = 'google';
    	$user->save();
    	}
    	$login_check = User::where('email',$getInfo->email)->first();
		Auth::loginUsingId($login_check->id);
		return redirect()->route('Select-Role');
    }

    public function job_search(request $request){
        return $request->Job;
    }

    public function form_store(request $request){
        $data  = new EnquiryForm();
        $data->Name  = $request->Name;
        $data->Email = $request->Email;
        $data->Mobile= $request->Mobile;
        $data->City  = $request->City;
        $data->Time  = $request->Time;
        $data->Date  = $request->Date;
        $data->save();
        $request->session()->flash('success','Form Submited Successfully!');
        return redirect()->route('Index');
    }
}
