<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Job;
use Auth;

class IndexController extends Controller
{
    public function index(){
    	$auth = Auth::user();
        if($auth->admin_role=='Admin'){
    	$job = Job::orderBy('id','desc')->get();
    	return view('Admin.Approve.Index',compact('job'));
    	 }
        else{
            return redirect('/');
        }
    }

    public function approve_store(request $request){
    	$job = Job::where('id',$request->Approve)->first();
    		if($job->AdminApprove==1)
    		{
    			$job->AdminApprove = 0;
    		}
    		else{
    			$job->AdminApprove = 1;
    		}
    		$job->save();
    	$request->session()->flash('success','Approved Successfully This Job Post');
    	return redirect()->route('Admin/Jobs/All');
    	
    }
}
