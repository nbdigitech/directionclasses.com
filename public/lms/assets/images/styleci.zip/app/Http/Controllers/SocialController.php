<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Socialite;
use App\User;
use Auth;
use Exception;

class SocialController extends Controller
{
	public function index($provider){
		return Socialite::driver($provider)->redirect();
	}

	public function linkedin_redirect(){
		return Socialite::driver('linkedin')->redirect();
	}

	public function linkedin_callback(request $request){
		if($request->has('error')){
 			return redirect()->route('Index');
		} 
		$linkdinUser = Socialite::driver('linkedin')->user();
		$check = User::where('email',$linkdinUser->email)->count();
		if($check==0){
		$user = new User();
    	$user->name = $linkdinUser->name;
    	$user->email = $linkdinUser->email;
    	$user->pic = $linkdinUser->avatar;
    	$user->provider_id = $linkdinUser->id;
    	$user->provider = 'linkedin';
    	$user->save();
		}
		$login_check = User::where('email',$linkdinUser->email)->first();
		Auth::loginUsingId($login_check->id);
		return redirect()->route('Select-Role');
	}
}
