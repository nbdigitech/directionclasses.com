<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Job;
use Session;
use App\User;
use App\CandidateApply;
use App\Profile;
class FindJobController extends Controller
{
    public function index(request $request){
        $data = Job::where('AdminApprove',1)->orderBy('id','desc')->paginate(9);
        return view('FindJob',compact('data'));
    }

    public function details(request $request, $id){
        $data = Job::where('id',$id)->first();
        return view('CompanyDetails',compact('data'));
    }

    public function apply(request $request){
        $jobid = Session::get('jobid');
        return view('Apply',compact('jobid'));
    }

    public function apply_store(request $request){
        $candidate = User::where('id',$request->CandidateId)->first();
        $apply_c = CandidateApply::where('CandidateId',$request->CandidateId)->where('JobId',$request->JobId)->count();
        $auth_id = Job::where('id',$request->JobId)->first();
        if($apply_c==0){
        $candidateapply = new CandidateApply();
        $candidateapply->CandidateId = $request->CandidateId;
        $candidateapply->JobId = $request->JobId;
        $candidateapply->UserId = $auth_id->UserId;
        $candidateapply->JobTitle = $auth_id->JobTitle;
        $candidateapply->AppliedEmail = $request->Email;
        $candidateapply->AppliedMobile = $request->Mobile;
        $candidateapply->save();
        }
        $request->session()->flash('success','submited success');
        return redirect()->route('FindJob');
    }
    public function session(request $request){
        $data = Session::put('jobid',$request->JobPostId);
        return redirect()->route('Job/Apply');
    }

    // public function searchsession(request $request){
    //  $jobs = $request->Job;
    //  $location = $request->Location;
    //  $data  =Job::where('JobTitle',$request->Job)->orWhere('City',$location)->get();
    //  return $data;
    // }
}
