<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use App\Address;
use App\Profile;
use App\Job;
use App\CandidateApply;
use Session;
use Auth;

class RegisteredUsersController extends Controller
{
    public function candidate(){
         $auth = Auth::user();
        if($auth->admin_role=='Admin'){
    	$candidate = User::where('role','Candidate')->orderBy('id','desc')->get();
    	return view('Admin.RegisteredUsers.Candidate',compact('candidate'));
        }
        else{
            return redirect('/');
        }
    }

    public function employer(){
         $auth = Auth::user();
        if($auth->admin_role=='Admin'){
        $employer = User::where('role','Employer')->orderBy('id','desc')->get();
        return view('Admin.RegisteredUsers.Employer',compact('employer'));
        }
        else{
            return redirect('/');
        }
    }

    public function delete(request $request){
        $data = User::where('id',$request->Delete)->first();
        $profile = Profile::where('UserId',$request->Delete)->first();
        $address = Address::where('UserId',$request->Delete)->first();
        if($data){
        $data->delete();
        }
        if($profile){
        $profile->delete();
        }
        if($profile){
        $address->delete();
        }
        $request->session()->flash('success','Deleted Successfully');
        return redirect()->back();
    }

    public function employer_details_session(request $request){
       Session::put('view_id',$request->View);
       return redirect()->route('Admin/Employer/Details');

    }

    public function employer_details(request $request){
         $auth = Auth::user();
        if($auth->admin_role=='Admin'){
        $view_id = Session::get('view_id');
        $user = User::where('id',$view_id)->first();
        $profile = Profile::where('UserId',$user->id)->first();
        $address = Address::where('UserId',$user->id)->first();
        $job = Job::where('UserId',$user->id)->get();
        return view('Admin.RegisteredUsers.EmployerDetails',compact('user','profile','address','job'));
        }
        else{
            return redirect('/');
        }
    }


    public function candidate_details_session(request $request){
       Session::put('view_id',$request->View);
       return redirect()->route('Admin/Candidate/Details');

    }

    public function candidate_details(request $request){
         $auth = Auth::user();
        if($auth->admin_role=='Admin'){
        $view_id = Session::get('view_id');
        $user = User::where('id',$view_id)->first();
        $profile = Profile::where('UserId',$user->id)->first();
        $address = Address::where('UserId',$user->id)->first();
        $jobapplied = CandidateApply::where('CandidateId',$user->id)->get();
        return view('Admin.RegisteredUsers.CandidateDetails',compact('user','profile','address','jobapplied'));
        }
        else{
            return redirect('/');
        }
    }

}
