<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use App\Address;
use App\EnquiryForm;
use Auth;

class EnquiryController extends Controller
{
    public function index(){
        $auth = Auth::user();
        if($auth->admin_role=='Admin'){
    	$data = EnquiryForm::orderBy('id','desc')->get();
    	return view('Admin.Forms.Index',compact('data'));
        }
        else{
            return redirect('/');
        }
    }
    public function delete(request $request){
        $data = EnquiryForm::where('id',$request->Delete)->first();
        $data->delete();
        $request->session()->flash('success','Deleted Successfully');
        return redirect()->route('Admin/EnquiryDetails');
    }
}
