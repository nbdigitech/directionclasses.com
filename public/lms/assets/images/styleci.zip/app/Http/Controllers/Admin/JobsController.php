<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use App\Job;
use Session;
use Auth;

class JobsController extends Controller
{
    public function all(){
        $auth = Auth::user();
        if($auth->admin_role=='Admin'){
    	$data = Job::orderBy('id','desc')->get();
    	return view('Admin.Jobs.All',compact('data'));
         }
        else{
            return redirect('/');
        }
    }

    public function approve(){
        $auth = Auth::user();
        if($auth->admin_role=='Admin'){
        $data = Job::where('AdminApprove','0')->orderBy('id','desc')->get();
        return view('Admin.Jobs.Approve',compact('data'));
         }
        else{
            return redirect('/');
        }
    }

     public function approve_store(request $request){
        $job = Job::where('id',$request->Approve)->first();
            if($job->AdminApprove==1)
            {
                $job->AdminApprove = 0;
            }
            else{
                $job->AdminApprove = 1;
            }
            $job->save();
        $request->session()->flash('success','Approved Successfully This Job Post');
        return redirect()->route('Admin/Jobs/All');
    }

    public function detailssession(request $request){
        Session::put('id',$request->View);
        return redirect()->route('Admin/Jobs/Details');
    }

    public function details(request $request){
        $auth = Auth::user();
        if($auth->admin_role=='Admin'){
        $viewid = Session::get('id');
        $data = Job::where('id',$viewid)->first();
        return view('Admin.Jobs.JobDetails',compact('data'));
         }
        else{
            return redirect('/');
        }
    }
}
