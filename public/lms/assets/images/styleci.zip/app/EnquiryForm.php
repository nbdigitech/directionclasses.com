<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EnquiryForm extends Model
{
    protected $table = "enquiryforms";
}