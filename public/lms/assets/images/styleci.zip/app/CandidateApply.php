<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CandidateApply extends Model
{
    protected $table = "candidate_apply";
}