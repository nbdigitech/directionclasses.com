@extends('layouts.Master')
@section('headerid')
gradient
@endsection
@section('MainSection')
<div class="theme-layout" id="scrollup">
   <section>
      <div class="block">
         <div data-velocity="-.1" class="parallax scrolly-invisible no-parallax" style="background: url('{{url('/')}}/public/assets/images/resource/parallax3.jpg;') 50% 422.28px repeat scroll transparent;"></div>
         <div class="container">
            <div class="row">
               <div class="col-lg-12">
                  <div class="heading">
                     <h2>WorkIndia India's Best Job Portal</h2>
                  </div>
                  <div class="blog-sec">
                     <div class="row">
                        <div class="col-lg-6">
                           <div class="my-blog" style="padding-top: 30px; padding-bottom: 30px; border-top: none; box-shadow: rgba(0, 0, 0, 0.1) 0px 10px 20px;">
                              <div class="blog-details">
                                 <h3 style="font-weight: bold;">I am Employer</h3>
                                 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry </p>
                                 <div class="row" style="text-align: center;">
                                    <div class="col-sm-12" style="text-align: center;">
                                        <form action="{{route('Role/Store')}}" method="post">
                                          {{csrf_field()}}
                                          <input type="hidden" name="role" value="Employer">
                                           <input type="submit" value="Hire Now" style="font-weight: bold; border: none; background: rgb(251, 35, 106); color: white; width: 200px; border-radius: 5px; height: 60px;">
                                        </form>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-6">
                           <div class="my-blog" style="padding-top: 30px; padding-bottom: 30px; box-shadow: rgba(0, 0, 0, 0.1) 0px 10px 20px;">
                              <div class="blog-details">
                                 <h3><a style="font-weight: bold;">I am Candidate</a></h3>
                                 <p>1,09,000 job openings all over India</p>
                                 <div class="row">
                                    <div class="col-sm-12">
                                       <form action="{{route('Role/Store')}}" method="post">
                                          {{csrf_field()}}
                                          <input type="hidden" name="role" value="Candidate">
                                       <input type="submit" value="Get Job Now" style="font-weight: bold; border: none; background: rgb(251, 35, 106); color: white; width: 200px; border-radius: 5px; height: 60px;">
                                       </form>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   @if(session()->has('success'))
<div class="alert alert-success fixed-top" id="aler" role="alert" style="color:white;background: #3BC761;border:none;padding-top:20px; padding-bottom:20px;">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close" ><span aria-hidden="true">&times;</span></button>
  <strong style="color:white">Success!</strong> Please Select - what you want.
</div>
@endif
</div>
@endsection