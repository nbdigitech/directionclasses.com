@extends('Admin.layouts.Master')
@section('MainSection')
	<div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                  <div class="card-header card-header-primary card-header-icon" style="margin-top: -15px;">
                  <div style="background-color: #DE3743  ; padding: 10px; padding-left: 16px; padding-top:16px; border-radius: 3px;" style="width: 100%;">
                    <h4>Job Details
                      </h4>
                  </div>

                </div>
                <div class="card-body">
                 <div class="row">
                   <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">JobTitle</p>
                      <div class="form-group">
                    <input type="text" disabled value="{{$data->JobTitle}}" class="form-control">
                  </div>
                   </div>
                   <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">JobType</p>
                      <div class="form-group">
                    <input type="text" disabled value="{{$data->JobType}}" class="form-control">
                  </div>
                   </div>
                   <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">JobCategory</p>
                      <div class="form-group">
                    <input type="text" disabled value="{{$data->JobCategory}}" class="form-control">
                  </div>
                   </div>
                   <div class="col-md-12">
                    <p style="font-weight: bold;margin-bottom: -13px;">JobDescription</p>
                      <div class="form-group">
                    <textarea type="text" rows="5" disabled class="form-control">{{$data->JobDescription}}"</textarea>
                  </div>
                   </div>
                   <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">Offered Sallary</p>
                      <div class="form-group">
                    <input type="text" disabled class="form-control" value="{{$data->OfferedSallary}}">
                  </div>
                   </div>
                   <div class="col-md-12">
                    <p style="font-weight: bold;margin-bottom: -13px;">Experience</p>
                      <div class="form-group">
                    <input type="text" disabled class="form-control" value="{{$data->Experience}}">
                  </div>
                   </div>
                   <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">Gender</p>
                      <div class="form-group">
                    <input type="text" disabled class="form-control" value="{{$data->Gender}}">
                  </div>
                </div>
                <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">Qualification</p>
                      <div class="form-group">
                    <input type="text" disabled class="form-control" value="{{$data->Qualification}}">
                  </div>
                </div>
                <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">ApplicationDeadLine</p>
                      <div class="form-group">
                    <input type="text" disabled class="form-control" value="{{$data->ApplicationDeadLine}}">
                  </div>
                </div>
                <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">Skill</p>
                      <div class="form-group">
                    <input type="text" disabled class="form-control" value="{{$data->Skill}}">
                  </div>
                </div>
                <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">City</p>
                      <div class="form-group">
                    <input type="text" disabled class="form-control" value="{{$data->City}}">
                  </div>
                </div>
                <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">State</p>
                      <div class="form-group">
                    <input type="text" disabled class="form-control" value="{{$data->State}}">
                  </div>
                </div>
                <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">Company Name</p>
                      <div class="form-group">
                    <input type="text" disabled  class="form-control" value="{{$data->CompanyName}}">
                  </div>
                </div>
                   <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">Complete Address</p>
                      <div class="form-group">
                    <input type="text" disabled class="form-control" value="{{$data->CompanyAddress}}">
                  </div>
                   </div>
                     
                  <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">Email</p>
                      <div class="form-group">
                    <input type="text" disabled  class="form-control" value="{{$data->Email}}">
                  </div>
                </div>

                 <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">Mobile Number</p>
                      <div class="form-group">
                    <input type="text" disabled  class="form-control" value="{{$data->Mobile}}">
                  </div>
                </div>
                 </div>
                <!-- end content-->
              </div>
              <!--  end card  -->
            </div>
            <!-- end col-md-12 -->
          </div>
        </div>
          <!-- end row -->
          
        </div>
      </div>
</div>




<!--##### EMAIL SENDING POPUP MODEL STARTS  #####-->
<div class="modal" id="SndMail">
    <div class="modal-dialog">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header"  style="background-color: #DE3743; color:white;">
          <h4 class="modal-title" style="margin-top: -10px; margin-bottom: 10px;">Are You Sure Rechedule it ?</h4>
          <button type="button" class="close" data-dismiss="modal" style="color:white;">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
         
        </div>

        <!-- Modal footer   col-form-label -->
        <div style="padding-bottom: 50px;">
          <div class="col-sm-2"></div>
        </div>

      </div>
    </div>
  </div>
<!--##### EMAIL SENDING POPUP MODEL ENDS  #####-->




<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header"  style="background-color: #DE3743; color:white;">
        <h4 class="modal-title" style="margin-top: -10px; margin-bottom: 10px;">Are You Sure Delete It ?</h4>
        <button type="button" class="close" data-dismiss="modal" style="color:white;">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body" style="text-align: center; padding-top: 50px;">
        If you are delete it. you can't get it after
      </div>

      <!-- Modal footer -->
      <div class="row" style="padding-bottom: 50px;">
        <div class="col-sm-2"></div>
        <div class="col-sm-4">
          <form action="http://nbdigitech.com/AdminPanel/Admin/Appointments/Delete" method="post">
            <input type="hidden" name="_token" value="wjTOPSyjLK33UTY7iZOqyXatiiUYJFMcxIGxBj7A">
            <input type="hidden" id="delete_id" name="Delete">

          <button type="submit" class="btn btn-success" style="color:white; margin-right: 50px; width: 100%;">Yes</button>
          </form>
        </div>
        <div class="col-sm-4">
          <button type="button" class="btn btn-danger" data-dismiss="modal" style="color:white; width: 100%; background-color: #DE3743;">No</button>
        </div>
        <div class="col-sm-2"></div>
      </div>
    </div>
  </div>
</div>

<div class="modal" id="SndRemark">
        <div class="modal-dialog">
          <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header"  style="background-color: #DE3743; color:white;">
              <h4 class="modal-title" style="margin-top: -10px; margin-bottom: 10px;">Are You Sure Remark It ?</h4>
              <button type="button" class="close" data-dismiss="modal" style="color:white;">&times;</button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
              
              <div class="container">      
                    <form action="http://nbdigitech.com/AdminPanel/Admin/Appointment/EditRemarkSession" method="post">
                      <input type="hidden" name="_token" value="wjTOPSyjLK33UTY7iZOqyXatiiUYJFMcxIGxBj7A">
                        <input type="hidden" name="EditRemarkId" id="remId" />
                        <label class="">Description:</label>

                            <div class="form-group">
                                <textarea id="full-featured" class="form-control" rows="10" name="Remark" ></textarea>
                            </div>

                        <div class="form-group">
                            <input type="submit" class="btn btn-success" style="color:white; margin-right: 50px; box-shadow:none" value="SEND">
                        </div>


                    </form>
                </div>
            </div>

            <!-- Modal footer   col-form-label -->
            <div style="padding-bottom: 50px;">
              <div class="col-sm-2"></div>
            </div>

          </div>
        </div>
      </div>
    <!--##### MESSAGE SENDING POPUP MODEL ENDS  #####-->


    <!--##### APPOINTMENT DONE POPUP MODEL STARTS  #####-->
<div class="modal" id="SndDone"><div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header"  style="background-color: #DE3743; color:white;">
        <h4 class="modal-title" style="margin-top: -10px; margin-bottom: 10px;">Are You Sure Close This Appointment It ?</h4>
        <button type="button" class="close" data-dismiss="modal" style="color:white;">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body" style="text-align: center; padding-top: 50px;">
        If you are Close This Appointment. you can't get it after
      </div>

      <!-- Modal footer -->
      <div class="row" style="padding-bottom: 50px;">
        <div class="col-sm-2"></div>
        <div class="col-sm-4">
          <form action="http://nbdigitech.com/AdminPanel/Admin/Appointments/Appointment-Done" method="post">
            <input type="hidden" name="_token" value="wjTOPSyjLK33UTY7iZOqyXatiiUYJFMcxIGxBj7A">
            <input type="hidden" id="Appointment_Done" name="AppointmentDone">

          <button type="submit" class="btn btn-success" style="color:white; margin-right: 50px; width: 100%;">Yes</button>
          </form>
        </div>
        <div class="col-sm-4">
          <button type="button" class="btn btn-danger" data-dismiss="modal" style="color:white; width: 100%; background-color: red;">No</button>
        </div>
        <div class="col-sm-2"></div>
      </div>
    </div>
  </div>
      </div>
@endsection