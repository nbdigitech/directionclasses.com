@extends('Admin.layouts.Master')
@section('MainSection')
	<div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                  <div class="card-header card-header-primary card-header-icon" style="margin-top: -15px;">
                  <div style="background-color: #DE3743  ; padding: 10px; padding-left: 16px; padding-top:16px; border-radius: 3px;" style="width: 100%;">
                    <h4>Manage Employers
                      </h4>
                  </div>

                </div>
                <div class="card-body">
                  <div class="toolbar">
                  </div>
                  <div class="material-datatables">
                    <table id="datatables" class="table table-no-bordered" cellspacing="0" width="100%" style="width:100%">
                      <thead>
                        <tr>
                          <th style="font-weight: bold;">#</th>
                          <th style="font-weight: bold;">Name</th>
                          <th style="font-weight: bold;">Email</th>
                          <th style="font-weight: bold;">RegisteredDate</th>
                          <th style="font-weight: bold;">View</th>
                          <th style="font-weight: bold;">Delete</th>
               
                        </tr>
                      </thead>
                      <tbody>
                     @php $i = 1; @endphp
                     @foreach($employer as $row)
                       <tr>
                          <td>{{$i++}}</td>
                          <td>{{$row->name}}</td>
                          <td>{{$row->email}}</td>
                          <td>{{$row->created_at}}</td>
                          <td><form action="{{route('Admin/Employer/DetailsSession')}}" method="post">
                              {{csrf_field()}}
                              <input type="hidden" name="View" value="{{$row->id}}">
                              <button title="Click To View Details" type="submit" class="btn btn-success">
                                View
                              </button>
                             </form>
                           </td>

                           <td><form action="{{route('Admin/RegisteredUsers/Delete')}}" method="post">
                              {{csrf_field()}}
                              <button title="Click To Delete" type="button" onclick="delete_function('{{$row->id}}')" data-toggle="modal" data-target="#myModal" class="btn btn-success">
                                Delete
                              </button>
                             </form>
                           </td>
                          </td>
                        </tr>
                       @endforeach
                        </tbody>
                    </table>
                  </div>
                </div>
                <!-- end content-->
              </div>
              <!--  end card  -->
            </div>
            <!-- end col-md-12 -->
          </div>
          <!-- end row -->
        </div>
      </div>
</div>

<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header"  style="background-color: #DE3743; color:white;">
        <h4 class="modal-title" style="margin-top: -10px; margin-bottom: 10px;">Are You Sure Delete It ?</h4>
        <button type="button" class="close" data-dismiss="modal" style="color:white;">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body" style="text-align: center; padding-top: 50px;">
        If you are delete it. you can't get it after
      </div>

      <!-- Modal footer -->
      <div class="row" style="padding-bottom: 50px;">
        <div class="col-sm-2"></div>
        <div class="col-sm-4">
          <form action="{{route('Admin/RegisteredUsers/Delete')}}" method="post">
            {{csrf_field()}}
            <input type="hidden" id="delete_id" name="Delete">

          <button type="submit" class="btn btn-success" style="color:white; margin-right: 50px; width: 100%;">Yes</button>
          </form>
        </div>
        <div class="col-sm-4">
          <button type="button" class="btn btn-danger" data-dismiss="modal" style="color:white; width: 100%; background-color: #DE3743;">No</button>
        </div>
        <div class="col-sm-2"></div>
      </div>
    </div>
  </div>
</div>

  <script type="text/javascript">
    function delete_function(id){
      document.getElementById('delete_id').value = id;
    }
  </script>
@endsection