@extends('layouts.Master')
@section('headerid')
gradient
@endsection
@section('MainSection')
   <div class="alert-box success">Changes saved successfull !!!</div>
         <section>
            <div class="block no-padding  gray">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12">
                        <div class="inner2">
                           <div class="inner-title2">
                              <h3>Job Post</h3>
                              <span>Keep up to date with the latest news</span>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
  <section>
      <div class="block no-padding">
         <div class="container">
             <div class="row no-gape">
               <div class="col-lg-12 column">
                  <div class="padding-left">
                     <div class="profile-form-edit">
                        <form action="@if(isset($edit->id)) {{route('Profile/JobPost/Update')}} @else {{route('Profile/JobPost/Store')}} @endif" method="post" enctype="multipart/form-data">
                           @if(isset($edit->id))
                           <input type="hidden" name="Update" value="{{$edit->id}}">
                            @endif
                           {{csrf_field()}}
                           <div class="row">
                              <div class="col-lg-12">
                                 <span class="pf-title">Job Title</span>
                                 <div class="pf-field">
                                    <input type="text" placeholder="Designer" name="JobTitle" required value="@if(isset($edit->id)) {{$edit->JobTitle}} @endif" />
                                 </div>
                              </div>
                              <div class="col-lg-12">
                                 <span class="pf-title">Description</span>
                                 <div class="pf-field">
                                    <textarea name="JobDescription">@if(isset($edit->id)) {{$edit->JobDescription}}@else Spent several years working on sheep on Wall Street. Had moderate success investing in Yugos on Wall Street. Managed a small team buying and selling pogo sticks for farmers. Spent several years licensing licorice in West Palm Beach, FL. Developed severalnew methods for working with banjos in the aftermarket. Spent a weekend importing banjos in West Palm Beach, FL.In this position, the Software Engineer ollaborates with Evention's Development team to continuously enhance our current software solutions as well as create new solutions to eliminate the back-office operations and management challenges present
                                     @endif</textarea>
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">Contact Email</span>
                                 <div class="pf-field">
                                    <input type="text" name="Email" value="@if(isset($edit->id)) {{$edit->Email}} @endif" />
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">Contact Number</span>
                                 <div class="pf-field">
                                    <input type="text" name="Mobile"  value="@if(isset($edit->id)) {{$edit->Mobile}} @endif" />
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">Job Type</span>
                                 <div class="pf-field">
                                    <select required name="JobType" data-placeholder="Please Select Specialism" class="chosen">
                                       <option value="Full Time" @if(isset($edit->id)) @if($edit->JobType=='Full Time') Selected @endif @endif>Full Time</option>
                                       <option value="Half Time" @if(isset($edit->id)) @if($edit->JobType=='Half Time') Selected @endif @endif>Half Time</option>
                                       <option value="Freelance" @if(isset($edit->id)) @if($edit->JobType=='Freelance') Selected @endif @endif>Freelance</option>
                                    </select>
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">Category</span>
                                 <div class="pf-field">
                                    <select required data-placeholder="Please Select Specialism" name="JobCategory" class="chosen">
                                       <option value="Web Development" @if(isset($edit->id)) @if($edit->Category=='Web Development') Selected @endif @endif>Web Development</option>
                                       <option value="Web Designing" @if(isset($edit->id)) @if($edit->Category=='Web Designing') Selected @endif @endif>Web Designing</option>
                                       <option value="Content Writer" @if(isset($edit->id)) @if($edit->Category=='Content Writer') Selected @endif @endif>Content Writer</option>
                                       <option value="Graphics Designer" @if(isset($edit->id)) @if($edit->Category=='Graphics Designer') Selected @endif @endif>Graphics Designer</option>
                                    </select>
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">Offerd Salary</span>
                                 <div class="pf-field">
                                    <input type="text" name="OfferedSallary" value="@if(isset($edit->id)) {{$edit->OfferedSallary}} @endif" />
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">Experience</span>
                                 <div class="pf-field">
                                    <select data-placeholder="Please Select Specialism" name="Experience" class="chosen">
                                       <option value="0-1 Year" @if(isset($edit->id)) @if($edit->Experience=='1-2 Year') Selected @endif @endif>0-1 Year </option>
                                       <option value="1-2 Year" @if(isset($edit->id)) @if($edit->Experience=='2-3 Year') Selected @endif @endif>1-2 Year </option>
                                       <option value="2-3 Year" @if(isset($edit->id)) @if($edit->Experience=='3-4 Year') Selected @endif @endif>2-3 Year </option>
                                       <option value="4-5 Year" @if(isset($edit->id)) @if($edit->Experience=='4-5 Year') Selected @endif @endif>4-5 Year </option>
                                       <option value="5-6 Year" @if(isset($edit->id)) @if($edit->Experience=='5-6 Year') Selected @endif @endif>5-6 Year </option>
                                       <option value="6-7 Year" @if(isset($edit->id)) @if($edit->Experience=='6-7 Year') Selected @endif @endif>6-7 Year </option>
                                       <option value="7-8 Year" @if(isset($edit->id)) @if($edit->Experience=='7-8 Year') Selected @endif @endif>7-8 Year </option>
                                       <option value="8-9 Year" @if(isset($edit->id)) @if($edit->Experience=='8-9 Year') Selected @endif @endif>8-9 Year </option>
                                       <option value="9-10 Year" @if(isset($edit->id)) @if($edit->Experience=='9-10 Year') Selected @endif @endif>9-10 Year </option>
                                    </select>
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">Gender</span>
                                 <div class="pf-field">
                                    <select name="Gender" required data-placeholder="Please Select Specialism" class="chosen">
                                       <option value="Male" @if(isset($edit->id)) @if($edit->Gender=='Male') Selected @endif @endif>Male</option>
                                       <option value="Female" @if(isset($edit->id)) @if($edit->Gender=='Female') Selected @endif @endif>Female</option>
                                       <option value="Male - Female Both" @if(isset($edit->id)) @if($edit->Gender=='Male - Female Both') Selected @endif @endif>Male - Female Both</option>
                                    </select>
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">Qualification</span>
                                 <div class="pf-field">
                                    <select required name="Qualification" data-placeholder="Please Select Specialism" class="chosen">
                                       <option value="10th Passout" @if(isset($edit->id)) @if($edit->Qualification=='10th Passout') Selected @endif @endif>10th Passout </option>
                                       <option value="12th Passout" @if(isset($edit->id)) @if($edit->Qualification=='12th Passout') Selected @endif @endif>12th Passout</option>
                                       <option value="Graduate" @if(isset($edit->id)) @if($edit->Qualification=='Graduate') Selected @endif @endif>Graduate</option>
                                       <option value="Post Graduate" @if(isset($edit->id)) @if($edit->Qualification=='Post Graduate') Selected @endif @endif>Post Graduate</option>
                                    </select>
                                 </div>
                              </div>
                              <div class="col-lg-12">
                                 <span class="pf-title">Application Deadline Date</span>
                                 <div class="pf-field">
                                    <input type="text" value="@if(isset($edit->id)) {{$edit->ApplicationDeadline}} @endif" placeholder="01.11.207" name="ApplicationDeadline"  class="form-control datepicker" />
                                 </div>
                              </div>
                              <div class="col-lg-12">
                                 <span class="pf-title">Skill Requirments</span>
                                 <div class="pf-field">
                                    <ul class="tags">
                                         <li class="addedTag">Photoshop<span onclick="$(this).parent().remove();" class="tagRemove">x</span><input type="hidden" name="Sklls[]" value="Web Deisgn"></li>
                                          <li class="tagAdd taglist">  
                                              <input type="text" id="search-field">
                                          </li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">Company Name</span>
                                 <div class="pf-field">
                                   <input type="text" required placeholder="Company Name" value="@if(isset($edit->id)) {{$edit->CompanyName}} @endif" name="CompanyName" />
                                 </div>
                              </div>

                               <div class="col-lg-6">
                                 <span class="pf-title">Company Logo</span>
                                 <div class="pf-field">
                                   <input type="file" value="@if(isset($edit->id)) {{$edit->Logo}} @endif" @if(!isset($edit->id)) required @endif name="Logo"/>
                                 </div>
                              </div>

                               <div class="col-lg-6">
                                 <span class="pf-title">City</span>
                                 <div class="pf-field">
                                   <input type="text" required placeholder="City" name="City" value="@if(isset($edit->id)) {{$edit->City}} @endif" />
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">State</span>
                                 <div class="pf-field">
                                    <select required name="State" data-placeholder="Please Select Specialism" class="chosen">
                                       <option>Chhattisgarh</option>
                                       
                                    </select>
                                 </div>
                              </div>
                              <div class="col-lg-12">
                                 <span class="pf-title">Complete Address</span>
                                 <div class="pf-field">
                                    <textarea name="CompleteAddress">@if(isset($edit->id)) {{$edit->CompleteAddress}} @endif</textarea>
                                 </div>
                                 <button type="submit" style="width: 100%; margin-bottom: 20px;"> Submit Now</button>
                              </div>
                              
                           </div>
                        </form>
                     </div>
                    
                  </div>
               </div>
             </div>
         </div>
      </div>
   </section>

@endsection