@extends('layouts.Master')
@section('headerid')
gradient
@endsection
@section('MainSection')
   <div class="alert-box success">Changes saved successfull !!!</div>
         <section>
            <div class="block no-padding  gray">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12">
                        <div class="inner2">
                           <div class="inner-title2">
                              <h3>Job Post</h3>
                              <span>Keep up to date with the latest news</span>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
<section>
      <div class="block">
         <div class="container">
            <div class="row">
               <div class="col-lg-8 column">
                  <div class="job-single-sec style3">
                     <div class="job-wide-devider">
                      
                        <div class="job-details">
                           <h2>Job Details</h2>
                           <br>
                           <h3>Job Title -</h3>
                           <p>{{$data->JobTitle}} . </p>
                            <h3>Job Description -</h3>
                           <p>{{$data->JobDescription}}</p>
                           <ul>
                              <li>Qualification – {{$data->Qualification}}</li>
                              <li>Experience - {{$data->Experience}}</li>
                              <li>Skills - {{$data->Skills}}</li>
                              
                           </ul><br>
                           <h3>Companty Info & Location</h3>
                           <p>Companany Name - {{$data->CompanyName}}</p>
                           <p>Location - {{$data->City}}</p>
                           <p></p>
                        </div>
                       
                      </div>
                  </div>
               </div>
               <div class="col-lg-4 column">
                  <div class="job-single-head style2">
                     <div class="job-thumb"> <img style="padding:10px; height: 70px; width: 100px;" src="{{url('/')}}/public/assets/uploads/{{$data->Logo}}" alt=""  style="width: 100px" /> </div>
                     <div class="job-head-info">
                        <h4>{{$data->CompanyName}}</h4>
                        <p><i class="la la-phone"></i> {{$data->Mobile}}</p>
                        <p><i class="la la-envelope-o"></i> <a href="/cdn-cgi/l/email-protection" class="__cf_email__">{{$data->Email}}</a></p>
                     </div>
                     <div class="emply-btns">
                        @if(Auth::user())
                        <form action="{{route('Job/Apply/Session')}}" method="post">{{csrf_field()}}
                        <input type="hidden" name="JobPostId" value="{{$data->id}}">
                        <button  type="submit" style=" margin-top: 10px; width: 100%; padding:20px; border-radius: 50px; background: #fb236a;color:white;">APPLY NOW</button>
                        </form>
                        @else
                        <a href="#" class="signup-popup" style=" border:none; border-radius: 50px; background: #fb236a;color:white;">APPLY NOW</a>
                       @endif
                     </div>
                  </div><!-- Job Head -->
               </div>
            </div>
         </div>
      </div>
   </section>

@endsection