@extends('layouts.Master')
@section('headerid')
gradient
@endsection
@section('MainSection')
<style type="text/css">
.card-head{
   text-align: left;
   cursor: none;
   background-color:#273244;
   color:white;
   padding:10px;
   margin-top: -10px;
   font-weight: normal;
}

#aler{
   width:400px;
   float: right;
}

#exampleModalLabel{
   text-align: center;
   margin-top: 60px;
}

#mydesign input, #select{
   margin-top: 30px;
}

#c{
   margin-right: 90px
}

#d{
   margin-right: 20px
}

#exampleModalLabel i{
   color:#F9D79F;
   font-weight: normal;
   font-size: 40px;
   border:2px solid #F9D79F;
   border-radius: 50px;
   padding:30px;
   font-weight: normal;
}

.modal-body h5{
   text-align: center;
}

.model-body .footer{
   text-align: center;
   margin-bottom: 30px
   margin-top:30px;
}

.footer button{
   padding-left: 30px; padding-right: 30px;
   padding-top:10px;
   padding-bottom:10px;

}

.modal-body h2{
   text-align: center;
   margin-top: 10px;
   font-weight: bold;
   color:#595959;
}

#list{
   font-size: 15px;
}

.input-group #input-group-addon{
   width: 40px;
}

.fa-mobile{
   font-size: 20px;
   margin-top: 10px;
}

.input-group textarea{
   padding-top: 20px;
}

.fa-location-arrow{
   margin-top:20px;
}

 .fa-phone{
   margin-top: 50px;
}

@media(max-width: 768px){
   #c{
   margin-right: 5px;

}

#aler{
   width:100%;
}

#d{
   margin-right: 5px
}
}

</style>
   <div class="theme-layout" id="scrollup">
   <br><br>
   <section class="overlape">
      <div class="container">
         <form action="#" method="get">
            <div class="row">
               <div class="col-lg-7 col-md-5 col-sm-12 col-xs-12" style="margin-top: 20px;">
                  <div class="job-field">
                     <input type="text" style="border:1px solid black;" placeholder="Job title, keywords or company name" />
                     <i class="la la-keyboard-o"></i>
                  </div>
               </div>
               <div class="col-lg-4 col-md-5 col-sm-12 col-xs-12" style="margin-top: 20px;">
                  <div class="job-field">
                     <input type="text" style="width: 100%; border:1px solid black;" placeholder="Search Job in Your Location">
                        
                     <i class="la la-map-marker"></i>
                  </div>
               </div>
               <div class="col-lg-1 col-md-2 col-sm-12 col-xs-12" style="margin-top: 20px;">
                  <button type="submit" style="background: #fb236a; border-radius: 5px; height: 60px;  width: 100%;"><i class="la la-search" style="font-size: 18px;"></i></button>
               </div>
            </div>
         </form>
      </div>
   </section>
 <section>
      <div class="block">
         <div class="container">
             <div class="row">
               <div class="col-lg-12">
              
                  <div class="job-grid-sec">
                     <div class="row">
                        @foreach($data as $row)
                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                           <div class="job-grid border">
                              <p style="float: right; margin-bottom: 50px;">Post Date :- {{$row->Date}}</p>
                              <a style="border:none;" href="{{url('FindJob/Details',$row->id)}}">
                              <div class="job-title-sec">
                                 <div class="c-logo" style="margin-top: -30px; height: 100px; width: 150px; text-align: center; margin-left: 100px;"> <img style="width: 100px;" src="{{url('/')}}/public/assets/uploads/{{$row->Logo}}" alt="" /> </div>
                                 <h3><a href="#" title="">{{$row->JobTitle}}</a></h3>
                                 <span>{{$row->CompanyName}}</span>
                              </div>
                              </a>
                              <span class="job-lctn">{{$row->City}}</span>
                              @if(Auth::user())
                              <form action="{{route('Job/Apply/Session')}}" method="post">{{csrf_field()}}
                                 <input type="hidden" name="JobPostId" value="{{$row->id}}">
                              <button  type="submit" style=" margin-top: 10px; border-radius: 10px; background: #fb236a;color:white;">APPLY NOW</button>
                              </form>
                              @else
                             
                              <a class="signup-popup" href="#" style=" margin-top: 10px; border-radius: 10px; background: #fb236a;color:white;">APPLY NOW</a>
                            
                              @endif

                           </div><!-- JOB Grid -->
                        </div>
                      @endforeach
                     </div>
                  </div>
                  <div class="pagination">
                    {{$data->links()}}
                  </div><!-- Pagination -->
               </div>
             </div>
         </div>
      </div>
   </section>
</div>

@if(session()->has('success'))
<div class="alert alert-success fixed-top" id="aler" role="alert" style="color:white;background: #3BC761;border:none;padding-top:20px; padding-bottom:20px;">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close" ><span aria-hidden="true">&times;</span></button>
  <strong style="color:white">Success!</strong> {{session()->get('success')}}
</div>
@endif
@endsection