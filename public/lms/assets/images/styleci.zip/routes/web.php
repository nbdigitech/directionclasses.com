<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('','IndexController@index')->name('Index');

Route::get('callback/{provider}','IndexController@callback');

Route::get('/About','AboutController@index')->name('About');

Route::get('/FindJob','FindJobController@index')->name('FindJob');

Route::post('/FindJob/Session','FindJobController@searchsession')->name('FindJob/Session');

Route::get('/Contact','ContactController@index')->name('Contact');

Route::get('/Social/{provider}','SocialController@index')->name('Social');

Route::get('/Linkedin','SocialController@linkedin_redirect')->name('Linkedin');

Route::get('/Linkedin/Callback','SocialController@linkedin_callback')->name('Linkedin/Callback');

Route::get('/Job/Apply','FindJobController@apply')->name('Job/Apply');

Route::post('/Job/Apply/Session','FindJobController@session')->name('Job/Apply/Session');

Route::post('/Job/Apply/Store','FindJobController@apply_store')->name('Job/Apply/Store');

Route::get('/FindJob/Details/{id}','FindJobController@details')->name('FindJob/Details');

Route::get('login','IndexController@login')->name('login');

Route::post('Job-Search','IndexController@job_search')->name('Job-Search');

Route::post('Form/Store','IndexController@form_store')->name('Form/Store');

Route::group(['middleware'=>'auth'], function(){

Route::get('/Select-Role','ProfileController@select')->name('Select-Role');

Route::post('/Role/Store','ProfileController@role_store')->name('Role/Store');

Route::get('/Profile','ProfileController@index')->name('Profile');

Route::post('/Profile/Store','ProfileController@store')->name('Profile/Store');

Route::post('/Profile/JobRole/Store','ProfileController@job_role_store')->name('Profile/JobRole/Store');

Route::get('/Profile/JobPost','ProfileController@job_post')->name('Profile/JobPost');

Route::get('/Profile/AppliedCandidates','ProfileController@appliedcandidae')->name('Profile/AppliedCandidates');

Route::post('/Profile/AppliedCandidates/Delete','ProfileController@appliedcandidae_delete')->name('Profile/AppliedCandidates/Delete');

Route::get('/Profile/JobPost/List','ProfileController@job_post_list')->name('Profile/JobPost/List');

Route::get('CandidateDetails/{id}','ProfileController@c_details');

Route::post('/Profile/JobPost/Delete','ProfileController@job_post_delete')->name('Profile/JobPost/Delete');

Route::post('/Profile/Job-Post/EditSession','ProfileController@editsession')->name('Profile/Job-Post/EditSession');

Route::get('/Profile/Job-Post/Edit','ProfileController@jobedit')->name('Profile/Job-Post/Edit');

Route::post('/Profile/JobPost/Update','ProfileController@jobupdate')->name('Profile/JobPost/Update');

Route::post('/Profile/JobPost/Store','ProfileController@job_store')->name('Profile/JobPost/Store');

Route::post('/Profile/Qualification/Store','ProfileController@qualification_store')->name('Profile/Qualification/Store');

Route::post('/Profile/Address/Store','ProfileController@address_store')->name('Profile/Address/Store');

Route::post('logout','ProfileController@logout')->name('logout');












///Admin Panel
Route::get('/Admin/Index','Admin\IndexController@index')->name('Admin/Index');	

Route::get('/Admin/Jobs/All','Admin\JobsController@all')->name('Admin/Jobs/All');	

Route::get('/Admin/Jobs/DetailsSession','Admin\JobsController@detailssession')->name('Admin/Jobs/DetailsSession');

Route::get('/Admin/Jobs/Details','Admin\JobsController@details')->name('Admin/Jobs/Details');

Route::get('/Admin/Jobs/Approve','Admin\JobsController@approve')->name('Admin/Jobs/Approve');

Route::post('/Admin/Aprove/Store','Admin\IndexController@approve_store')->name('Admin/Aproove/Store');	

Route::post('/Admin/Index','Admin\IndexController@index');	

Route::get('/Admin/Candidate','Admin\RegisteredUsersController@candidate')->name('Admin/Candidate');

Route::post('/Admin/RegisteredUsers/Delete','Admin\RegisteredUsersController@delete')->name('Admin/RegisteredUsers/Delete');

Route::get('/Admin/Employer','Admin\RegisteredUsersController@employer')->name('Admin/Employer');

Route::post('/Admin/Employer/DetailsSession','Admin\RegisteredUsersController@employer_details_session')->name('Admin/Employer/DetailsSession');

Route::get('/Admin/Candidate/Details','Admin\RegisteredUsersController@candidate_details')->name('Admin/Candidate/Details');

Route::post('/Admin/Candidate/DetailsSession','Admin\RegisteredUsersController@candidate_details_session')->name('Admin/Candidate/DetailsSession');

Route::get('/Admin/Employer/Details','Admin\RegisteredUsersController@employer_details')->name('Admin/Employer/Details');

Route::get('/Admin/EnquiryDetails','Admin\EnquiryController@index')->name('Admin/EnquiryDetails');

Route::post('/Admin/EnquiryDetails/Delete','Admin\EnquiryController@delete')->name('Admin/EnquiryDetails/Delete');
///
});
