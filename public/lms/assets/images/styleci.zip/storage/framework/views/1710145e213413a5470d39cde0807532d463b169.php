<?php echo $__env->make('layouts.Header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<div id="scrollup">
<?php echo $__env->make('layouts.Navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('MainSection'); ?>
<?php echo $__env->make('layouts.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<style type="text/css">
.button {
  width: 100%;
  display: inline-block;
  padding: 0 18px 0 6px;
  border: 0 none;
  border-radius: 5px;
  margin-top:10px;
  text-decoration: none;
  transition: all 250ms linear;
}
.button:hover {
  text-decoration: none;
  color:white;
}

.button--social-login {
  margin-bottom: 12px;
  margin-right: 12px;
  color: white;

  height: 60px;
  line-height: 60px;
  position: relative;
  text-align: left;
}
.button--social-login .icon {
  margin-right: 12px;
  font-size: 24px;
  line-height: 24px;
  width: 42px;
  height: 24px;
  text-align: center;
  display: inline-block;
  position: relative;
  top: 4px;
}
.button--social-login .icon:before {
  display: inline-block;
  width: 40px;
}
.button--social-login .icon:after {
  content: "";
}


.button--linkedin {
  background-color: #0087be;
  border: 1px solid #00638b;
}
.button--linkedin .icon {
  border-right: 1px solid #00638b;
}
.button--linkedin .icon:after {
  border-right: 1px solid #00abf1;
}
.button--linkedin:hover {
  background-color: #0075a5;
}


.button--googleplus {
  background-color: #DD4B39;
  border: 1px solid #c23321;
}
.button--googleplus .icon {
  border-right: 1px solid #c23321;
}
.button--googleplus .icon:after {
  border-right: 1px solid #e47365;
}
.button--googleplus:hover {
  background-color: #d73925;
}


</style>


<div class="account-popup-area signup-popup-box" >
	<div class="account-popup" style="border:5px solid #fb236a;">
		<span class="close-popup"><i class="la la-close"></i></span>
		<h3>Login Here</h3><br><br><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
		    <a class="button button--social-login button--googleplus" href="<?php echo e(url('Social/google')); ?>"><i class="icon fa fa-google"></i>Login With Google</a>    

<a class="button button--social-login button--linkedin" href="<?php echo e(url('Linkedin')); ?>"><i class="icon fa fa-linkedin"></i>Login With Linkedin</a><br><br>

	</div>
</div><!-- SIGNUP POPUP -->
<script src="<?php echo e(url('/')); ?>/public/assets/js/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo e(url('/')); ?>/public/assets/js/modernizr.js" type="text/javascript" async></script>
<script src="<?php echo e(url('/')); ?>/public/assets/js/script.js" type="text/javascript"></script>
<script src="<?php echo e(url('/')); ?>/public/assets/js/bootstrap.min.js" type="text/javascript" async></script>
<script src="<?php echo e(url('/')); ?>/public/assets/js/wow.min.js" type="text/javascript" async></script>
<script src="<?php echo e(url('/')); ?>/public/assets/js/parallax.js" type="text/javascript" async></script>
<script src="<?php echo e(url('/')); ?>/public/assets/js/select-chosen.js" type="text/javascript" async></script>
<script src="<?php echo e(url('/')); ?>/public/assets/js/tag.js" type="text/javascript"></script>
<script type="text/javascript">
  window.setTimeout(function() {
    $(".alert").fadeTo(500, 0).slideUp(500, function(){
        $(this).remove(); 
    });
}, 2000);
</script>
</body>
</html>

<?php /**PATH /home/glwsvozu/jobvacancy.app/resources/views/layouts/Master.blade.php ENDPATH**/ ?>