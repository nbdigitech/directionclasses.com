
<?php $__env->startSection('headerid'); ?>
gradient
<?php $__env->stopSection(); ?>
<?php $__env->startSection('MainSection'); ?>
   <div class="alert-box success">Changes saved successfull !!!</div>
         <section>
            <div class="block no-padding  gray">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12">
                        <div class="inner2">
                           <div class="inner-title2">
                              <h3>Job Post</h3>
                              <span>Keep up to date with the latest news</span>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
  <section>
      <div class="block no-padding">
         <div class="container">
             <div class="row no-gape">
               <div class="col-lg-12 column">
                  <div class="padding-left">
                     <div class="profile-form-edit">
                        <form action="<?php echo e(route('Job/Apply/Store')); ?>" method="post" enctype="multipart/form-data">
                           <?php echo e(csrf_field()); ?>

                           <?php if(Auth::user()): ?>
                           <input type="hidden" name="CandidateId" value="<?php echo e(Auth::user()->id); ?>">
                           <?php endif; ?>
                           <input type="hidden" name="JobId" value="<?php echo e($jobid); ?>">
                           <div class="row">
                              <div class="col-lg-12">
                                 <span class="pf-title">Email</span>
                                 <div class="pf-field">
                                    <input type="email" placeholder="Email Address... " name="Email" required />
                                 </div>
                              </div>
                              <div class="col-lg-12">
                                 <span class="pf-title">Mobile Number</span>
                                 <div class="pf-field">
                                    <input type="number" placeholder="Mobile Number... " name="Mobile" required />
                                 </div>
                              </div>

                               <div class="emply-btns">
                        <button type="submit" class="seemap" title="" style="width: 100%; margin-bottom: 20px; background: #fb236a;color:white;">Apply Now</button>
                       <!--  <a class="followus" href="#" title=""><i class="la la-paper-plane"></i> Follow us</a> -->
                     </div>
                            
                        </form>
                     </div>
                    
                  </div>
               </div>
             </div>
         </div>
      </div>
   </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/glwsvozu/jobvacancy.app/resources/views/Apply.blade.php ENDPATH**/ ?>