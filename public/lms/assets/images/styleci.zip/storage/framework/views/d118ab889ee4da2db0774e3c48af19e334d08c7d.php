<?php $__env->startSection('headerid'); ?>
stick-top forsticky
<?php $__env->stopSection(); ?>
<?php $__env->startSection('MainSection'); ?>
<section>
	<style type="text/css">
		#cll select{
				height: 50px;
			}
		@media(max-width: 768px){
			#cll{
				margin-top: 30px;
			}
			
		}
	</style>
		<div class="block no-padding">
			<div class="container fluid">
				<div class="row">
					<div class="col-lg-12">
						<div class="main-featured-sec">
							<div class="new-slide">
								<img src="<?php echo e(url('/')); ?>/public/assets/images/resource/vector-1.png">
							</div>
							<div class="job-search-sec">
								<div class="job-search">
									<h3>Search Job In Your City</h3>
									<span>Find Jobs, Employment & Career Opportunities</span>
									<form action="<?php echo e(route('FindJob')); ?>" method="get">
										<?php echo e(csrf_field()); ?>

										<div class="row">
											<div class="col-lg-7 col-md-5 col-sm-12 col-xs-12">
												<div class="job-field">
													<input type="text" name="Job" placeholder="Job title, keywords or company name" />
													<i class="la la-keyboard-o"></i>
												</div>
											</div>
											<div class="col-lg-4 col-md-5 col-sm-12 col-xs-12">
												<div class="job-field">
													<select name="Location" data-placeholder="City, province or region" class="chosen-city">
														<option>Raipur </option>
														<option>Bhilai</option>
														<option>Durg</option>
														<option>Bilaspur</option>
													</select>
													<i class="la la-map-marker"></i>
												</div>
											</div>
											<div class="col-lg-1 col-md-2 col-sm-12 col-xs-12">
												<button type="submit"><i class="la la-search"></i></button>
											</div>
										</div>
									</form>
								
								</div>
							</div>
						
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<section style="margin-top: -60px;">
		<div class="block">
			<div class="container">
				<form action="<?php echo e(route('Form/Store')); ?>" method="post">
				<div class="row" style="box-shadow: 0 10px 20px rgba(0,0,0,0.19), 0 6px 6px rgba(0,0,0,0.23); padding:30px;">
					<?php echo e(csrf_field()); ?>

						<div class="col-md-3" id="cll">
							<select required class="form-control" name="AreaEx">
								<option value="">Select Area of Ex.</option>
								<option value="Bhilai">Bhilai</option>
								<option value="Raipur">Raipur</option>
							</select>
						</div>
						<div class="col-md-3" id="cll">
							<select required class="form-control" name="IndustryEx">
								<option>Select Industry</option>
								<option value="36 INC">36 INC</option>
								<option value="NB Digital">NB Digital</option>
							</select>
						</div>
						<div class="col-md-3" id="cll">
							<select required class="form-control" name="BusinessEx">
								<option>Select Business Ex.</option>
								<option value="Bhusnesh Shrivastava">Bhunesh Shrivastava</option>
								<option value="Kaustubh Sharma">Kaustubh Sharma</option>
							</select>
						</div>
						<div class="col-md-3" id="cll"><center>
							<button type="submit" class="btn btn-success" style="background:#fb236a; border:none; width: 100%;margin:auto;float: left; height: 50px;">Submit Now</button></center>
						</div>
					</form>
				</div><br><br>
				<div class="row">
					<div class="col-lg-12">
						<center><h2 style="font-weight: bold;">Consultants</h2></center><br>
					</div>
				</div>
				 <div class="row">
				 	<div class="col-lg-12">
				 		<div class="blog-sec">
							<div class="row" id="masonry">
								<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
									<div class="my-blog">
										<div class="blog-thumb">
											<a href="#" title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/kaustubh.jpeg" alt=""  style="height: 350px;" /></a>
											<div class="blog-metas">
												Harsh Dubey
											</div>
										</div>
										<div class="blog-details">
											<h3><a href="#" title="" style="font-size: 15px;">Graduate : BE (Electronics & Telecommunication)</a></h3>
											<p>A job is a regular activity performed in exchange becoming an employee, volunteering, </p>
											
										</div>
									</div>
								</div>
								<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
									<div class="my-blog">
										<div class="blog-thumb">
											<a  title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/kaustubh.jpeg" style="height: 350px;" alt="" /></a>
											<div class="blog-metas">
												Kaustubh Sharma
											</div>
										</div>
										<div class="blog-details">
											<h3><a  title="" style="font-size: 15px;">BBA Graduate (Aspiring M-Lit English)</a></h3>
											<p>A job is a regular activity performed in exchange becoming an employee, volunteering, </p>
											
										</div>
									</div>
								</div>
								<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
									<div class="my-blog">
										<div class="blog-thumb">
											<a href="#" title=""><img style="height: 350px;" src="<?php echo e(url('/')); ?>/public/assets/images/Subhayu.jpeg" alt="" /></a>
											<div class="blog-metas">
												Dr. Subhayu Sikdar
											</div>
										</div>
										<div class="blog-details">
											<h3><a style="font-size: 15px;" title="">(International Studies) MD Physician</a></h3>
											<p>A job is a regular activity performed in exchange becoming an employee, volunteering, </p>
											
										</div>
									</div>
								</div>
							<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
									<div class="my-blog">
										<div class="blog-thumb">
											<a href="#" title=""><img style="height: 350px;" src="<?php echo e(url('/')); ?>/public/assets/images/Subhayu.jpeg" alt="" /></a>
											<div class="blog-metas">
												Bhuwnesh Shrivastava
											</div>
										</div>
										<div class="blog-details">
											<h3><a style="font-size: 15px;" title="">An Overworked Newspaper Editor</a></h3>
											<p>A job is a regular activity performed in exchange becoming an employee, volunteering, </p>
											
										</div>
									</div>
								</div>
					</div>
				 </div>
			</div>
		</div>
	</section>
	<section>
		<div class="block double-gap-top double-gap-bottom">
			<div data-velocity="-.1" style="background: url(<?php echo e(url('/')); ?>/public/assets/images/resource/parallax1.jpg) repeat scroll 50% 422.28px transparent;" class="parallax scrolly-invisible layer color"></div><!-- PARALLAX BACKGROUND IMAGE -->
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="simple-text-block">
							<h3>Make a Difference with Your Online Resume!</h3>
							<span>Your resume in minutes with Job Portal resume assistant is ready!</span>
							<a href="#" title="">Create an Account</a>
						</div>
					</div>
				</div>
			</div>	
		</div>
	</section>

	<section>
		<div class="block">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="heading">
							<h2>Featured Jobs</h2>
							<span>Leading Employers already using job and talent.</span>
						</div><!-- Heading -->
						<div class="job-listings-sec">
							<div class="job-listing">
								<div class="job-title-sec">
									<div class="c-logo"> <img src="<?php echo e(url('/')); ?>/public/assets/images/resource/l1.png" alt="" /> </div>
									<h3><a href="#" title="">Web Designer / Developer</a></h3>
									<span>Massimo Artemisis</span>
								</div>
								<span class="job-lctn"><i class="la la-map-marker"></i>Sacramento, California</span>
								<span class="fav-job"><i class="la la-heart-o"></i></span>
								<span class="job-is ft">FULL TIME</span>
							</div><!-- Job -->
							<div class="job-listing">
								<div class="job-title-sec">
									<div class="c-logo"> <img src="<?php echo e(url('/')); ?>/public/assets/images/resource/l2.png" alt="" /> </div>
									<h3><a href="#" title="">Marketing Director</a></h3>
									<span>Tix Dog</span>
								</div>
								<span class="job-lctn"><i class="la la-map-marker"></i>Rennes, France</span>
								<span class="fav-job"><i class="la la-heart-o"></i></span>
								<span class="job-is pt">PART TIME</span>
							</div><!-- Job -->
							<div class="job-listing">
								<div class="job-title-sec">
									<div class="c-logo"> <img src="<?php echo e(url('/')); ?>/public/assets/images/resource/l3.png" alt="" /> </div>
									<h3><a href="#" title="">C Developer (Senior) C .Net</a></h3>
									<span>StarHealth</span>
								</div>
								<span class="job-lctn"><i class="la la-map-marker"></i>London, United Kingdom</span>
								<span class="fav-job"><i class="la la-heart-o"></i></span>
								<span class="job-is ft">FULL TIME</span>
							</div><!-- Job -->
							<div class="job-listing">
								<div class="job-title-sec">
									<div class="c-logo"> <img src="<?php echo e(url('/')); ?>/public/assets/images/resource/l4.png" alt="" /> </div>
									<h3><a href="#" title="">Application Developer For Android</a></h3>
									<span>Altes Bank</span>
								</div>
								<span class="job-lctn"><i class="la la-map-marker"></i>Istanbul, Turkey</span>
								<span class="fav-job"><i class="la la-heart-o"></i></span>
								<span class="job-is fl">FREELANCE</span>
							</div><!-- Job -->
							<div class="job-listing">
								<div class="job-title-sec">
									<div class="c-logo"> <img src="<?php echo e(url('/')); ?>/public/assets/images/resource/l5.png" alt="" /> </div>
									<h3><a href="#" title="">Regional Sales Manager South east Asia</a></h3>
									<span>Vincent</span>
								</div>
								<span class="job-lctn"><i class="la la-map-marker"></i>Ajax, Ontario</span>
								<span class="fav-job"><i class="la la-heart-o"></i></span>
								<span class="job-is tp">TEMPORARY</span>
							</div><!-- Job -->
							<div class="job-listing">
								<div class="job-title-sec">
									<div class="c-logo"> <img src="<?php echo e(url('/')); ?>/public/assets/images/resource/l6.png" alt="" /> </div>
									<h3><a href="#" title="">Social Media and Public Relation Executive </a></h3>
									<span>MediaLab</span>
								</div>
								<span class="job-lctn"><i class="la la-map-marker"></i>Ankara / Turkey</span>
								<span class="fav-job"><i class="la la-heart-o"></i></span>
								<span class="job-is ft">FULL TIME</span>
							</div><!-- Job -->
						</div>
					</div>
					<div class="col-lg-12">
						<div class="browse-all-cat">
							<a href="#" title="">Load more listings</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section>
		<div class="block">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="heading">
							<h2>Companies We've Helped</h2>
							<span>Some of the companies we've helped recruit excellent applicants over the years.</span>
						</div><!-- Heading -->
						<div class="comp-sec">
							<div class="company-img">
								<a href="#" title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/resource/cc1.jpg" alt="" /></a>
							</div><!-- Client  -->
							<div class="company-img">
								<a href="#" title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/resource/cc2.jpg" alt="" /></a>
							</div><!-- Client  -->
							<div class="company-img">
								<a href="#" title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/resource/cc3.jpg" alt="" /></a>
							</div><!-- Client  -->
							<div class="company-img">
								<a href="#" title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/resource/cc4.jpg" alt="" /></a>
							</div><!-- Client  -->
							<div class="company-img">
								<a href="#" title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/resource/cc5.jpg" alt="" /></a>
							</div><!-- Client  -->
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="block">
			<div data-velocity="-.1" style="background: url(<?php echo e(url('/')); ?>/public/assets/images/resource/parallax3.jpg) repeat scroll 50% 422.28px transparent;" class="parallax scrolly-invisible no-parallax"></div><!-- PARALLAX BACKGROUND IMAGE -->
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="heading">
							<h2>Quick Career Tips</h2>
							<span>Found by employers communicate directly with hiring managers and recruiters.</span>
						</div><!-- Heading -->
						<div class="blog-sec">
							<div class="row">
								<div class="col-lg-4">
									<div class="my-blog">
										<div class="blog-thumb">
											<a href="#" title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/resource/b1.jpg" alt="" /></a>
											<div class="blog-metas">
												<a href="#" title="">March 29, 2017</a>
												<a href="#" title="">0 Comments</a>
											</div>
										</div>
										<div class="blog-details">
											<h3><a href="#" title="">Attract More Attention Sales And Profits</a></h3>
											<p>A job is a regular activity performed in exchange becoming an employee, volunteering, </p>
											
										</div>
									</div>
								</div>
								<div class="col-lg-4">
									<div class="my-blog">
										<div class="blog-thumb">
											<a href="#" title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/resource/b2.jpg" alt="" /></a>
											<div class="blog-metas">
												<a href="#" title="">March 29, 2017</a>
												<a href="#" title="">0 Comments</a>
											</div>
										</div>
										<div class="blog-details">
											<h3><a href="#" title="">11 Tips to Help You Get New Clients</a></h3>
											<p>A job is a regular activity performed in exchange becoming an employee, volunteering, </p>
											
										</div>
									</div>
								</div>
								<div class="col-lg-4">
									<div class="my-blog">
										<div class="blog-thumb">
											<a href="#" title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/resource/b3.jpg" alt="" /></a>
											<div class="blog-metas">
												<a href="#" title="">March 29, 2017</a>
												<a href="#" title="">0 Comments</a>
											</div>
										</div>
										<div class="blog-details">
											<h3><a href="#" title="">An Overworked Newspaper Editor</a></h3>
											<p>A job is a regular activity performed in exchange becoming an employee, volunteering, </p>
											
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="block no-padding">
			<div class="container fluid">
				<div class="row">
					<div class="col-lg-12">
						<div class="simple-text">
							<h3>Gat a question?</h3>
							<span>We're here to help. Check out our FAQs, send us an email or call us at 1 (800) 555-5555</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php if(session()->has('success')): ?>
<div class="alert alert-success fixed-top" id="aler" role="alert" style="color:white;background: #3BC761;border:none;padding-top:20px; padding-bottom:20px;">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close" ><span aria-hidden="true">&times;</span></button>
  <strong style="color:white">Success!</strong> <?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\job_vacancy\resources\views/Index.blade.php ENDPATH**/ ?>