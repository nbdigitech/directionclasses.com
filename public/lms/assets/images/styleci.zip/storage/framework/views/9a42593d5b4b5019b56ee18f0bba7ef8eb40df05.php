<?php $__env->startSection('headerid'); ?>
gradient
<?php $__env->stopSection(); ?>
<?php $__env->startSection('MainSection'); ?>
   <div class="theme-layout" id="scrollup">
   
   <section class="overlape">
      <div class="block no-padding">
         <div data-velocity="-.1" class="parallax scrolly-invisible no-parallax" style="background: url(&quot;<?php echo e(url('/')); ?>/public/assets//images/resource/mslider1.jpg&quot;) 50% -71.86px repeat scroll transparent;"></div>
         <div class="container fluid">
            <div class="row">
               <div class="col-lg-12">
                  <div class="inner-header">
                     <h3>Jobs In Your City</h3>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
  <section>
      <div class="block">
         <div class="container">
            <div class="row">
               <div class="col-lg-12">
                  <div class="heading">
                 
                  </div><!-- Heading -->
                  <div class="job-listings-sec">
                     <div class="job-listing">
                        <div class="job-title-sec">
                           <div class="c-logo"> <img src="<?php echo e(url('/')); ?>/public/assets/images/resource/l1.png" alt="" /> </div>
                           <h3><a href="#" title="">Web Designer / Developer</a></h3>
                           <span>Massimo Artemisis</span>
                        </div>
                        <span class="job-lctn"><i class="la la-map-marker"></i>Sacramento, California</span>
                        <span class="fav-job"><i class="la la-heart-o"></i></span>
                        <span class="job-is ft">FULL TIME</span>
                     </div><!-- Job -->
                     <div class="job-listing">
                        <div class="job-title-sec">
                           <div class="c-logo"> <img src="<?php echo e(url('/')); ?>/public/assets/images/resource/l2.png" alt="" /> </div>
                           <h3><a href="#" title="">Marketing Director</a></h3>
                           <span>Tix Dog</span>
                        </div>
                        <span class="job-lctn"><i class="la la-map-marker"></i>Rennes, France</span>
                        <span class="fav-job"><i class="la la-heart-o"></i></span>
                        <span class="job-is pt">PART TIME</span>
                     </div><!-- Job -->
                     <div class="job-listing">
                        <div class="job-title-sec">
                           <div class="c-logo"> <img src="<?php echo e(url('/')); ?>/public/assets/images/resource/l3.png" alt="" /> </div>
                           <h3><a href="#" title="">C Developer (Senior) C .Net</a></h3>
                           <span>StarHealth</span>
                        </div>
                        <span class="job-lctn"><i class="la la-map-marker"></i>London, United Kingdom</span>
                        <span class="fav-job"><i class="la la-heart-o"></i></span>
                        <span class="job-is ft">FULL TIME</span>
                     </div><!-- Job -->
                     <div class="job-listing">
                        <div class="job-title-sec">
                           <div class="c-logo"> <img src="<?php echo e(url('/')); ?>/public/assets/images/resource/l4.png" alt="" /> </div>
                           <h3><a href="#" title="">Application Developer For Android</a></h3>
                           <span>Altes Bank</span>
                        </div>
                        <span class="job-lctn"><i class="la la-map-marker"></i>Istanbul, Turkey</span>
                        <span class="fav-job"><i class="la la-heart-o"></i></span>
                        <span class="job-is fl">FREELANCE</span>
                     </div><!-- Job -->
                     <div class="job-listing">
                        <div class="job-title-sec">
                           <div class="c-logo"> <img src="<?php echo e(url('/')); ?>/public/assets/images/resource/l5.png" alt="" /> </div>
                           <h3><a href="#" title="">Regional Sales Manager South east Asia</a></h3>
                           <span>Vincent</span>
                        </div>
                        <span class="job-lctn"><i class="la la-map-marker"></i>Ajax, Ontario</span>
                        <span class="fav-job"><i class="la la-heart-o"></i></span>
                        <span class="job-is tp">TEMPORARY</span>
                     </div><!-- Job -->
                     <div class="job-listing">
                        <div class="job-title-sec">
                           <div class="c-logo"> <img src="<?php echo e(url('/')); ?>/public/assets/images/resource/l6.png" alt="" /> </div>
                           <h3><a href="#" title="">Social Media and Public Relation Executive </a></h3>
                           <span>MediaLab</span>
                        </div>
                        <span class="job-lctn"><i class="la la-map-marker"></i>Ankara / Turkey</span>
                        <span class="fav-job"><i class="la la-heart-o"></i></span>
                        <span class="job-is ft">FULL TIME</span>
                     </div><!-- Job -->
                  </div>
               </div>
               <div class="col-lg-12">
                  <div class="browse-all-cat">
                     <a href="#" title="">Load more listings</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_job\resources\views/FindJob.blade.php ENDPATH**/ ?>