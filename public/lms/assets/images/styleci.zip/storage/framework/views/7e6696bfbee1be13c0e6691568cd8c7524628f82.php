<?php $__env->startSection('headerid'); ?>
gradient
<?php $__env->stopSection(); ?>
<?php $__env->startSection('MainSection'); ?>
   <div class="alert-box success">Changes saved successfull !!!</div>
         <section>
            <div class="block no-padding  gray">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12">
                        <div class="inner2">
                           <div class="inner-title2">
                              <h3>Posted Jobs list</h3>
                              <span>Manage Posted Jobs - Delete, Update.</span>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
<section>
      <div class="block no-padding">
         <div class="container">
             <div class="row no-gape">
               <div class="col-lg-12 column">
                  <div class="padding-left">
                     <div class="manage-jobs-sec">
                        <h3>Manage Here</h3>
                        <table>
                           <thead>
                              <tr>
                                 <td>#</td>
                                 <td>Job Title</td>
                                 <td>Job Type</td>
                                 <td>Offered Sallary</td>
                                 <td>Post Date</td>
                                 <td>Action</td>
                              </tr>
                           </thead>
                           <tbody>
                           <?php $i = 1; ?>
                           <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                 <td>
                                    <span><?php echo e($i++); ?></span>
                                 </td>
                                 <td>
                                    <div class="table-list-title">
                                       <h3><a href="#" title=""><?php echo e($row->JobTitle); ?></a></h3>
                                    </div>
                                 </td>
                                  <td>
                                    <span class="status active"><?php echo e($row->JobType); ?></span>
                                 </td>
                                 <td>
                                    <span><?php echo e($row->OfferedSallary); ?></span>
                                 </td>
                                 <td>
                                    <span><?php echo e($row->created_at); ?></span>
                                 </td>
                                
                                 <td>
                                    <form action="<?php echo e(route('Profile/Job-Post/EditSession')); ?>" method="post"><?php echo e(csrf_field()); ?><input type="hidden" name="Edit" value="<?php echo e($row->id); ?>">
                                    <button type="submit" style="background: none;color:black; float: left;margin-left:-80px;margin-top: -6px;">Update</button> </form>|
                                    <form action="<?php echo e(route('Profile/JobPost/Delete')); ?>" method="post"><?php echo e(csrf_field()); ?><input type="hidden" name="Delete" value="<?php echo e($row->id); ?>">
                                    <button type="submit" style="background: none;color:black; float: left; margin-top: -30px;">Delete </button> </form>
                                 </td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
             </div>
         </div>
      </div>
   </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\job_vacancy\resources\views/PostedJobs.blade.php ENDPATH**/ ?>