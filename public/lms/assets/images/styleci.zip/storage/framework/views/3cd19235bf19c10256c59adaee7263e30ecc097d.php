<?php $__env->startSection('headerid'); ?>
gradient
<?php $__env->stopSection(); ?>
<?php $__env->startSection('MainSection'); ?>
<div class="theme-layout" id="scrollup">
   <section>
      <div class="block no-padding  gray">
         <div class="container">
            <div class="row">
               <div class="col-lg-12">
                  <div class="inner2">
                     <div class="inner-title2">
                        <h3>Contact</h3>
                        <span>Keep up to date with the latest news</span>
                     </div>
                     <div class="page-breacrumbs">
                        <ul class="breadcrumbs">
                           <li><a href="/">Home</a></li>
                           <li>Contact</li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <section>
      <div class="block">
         <div class="container">
            <div class="row">
               <div class="col-lg-6 column">
                  <div class="contact-form">
                     <h3>Keep In Touch</h3>
                     <form>
                        <div class="row">
                           <div class="col-lg-12">
                              <span class="pf-title">Full Name</span>
                              <div class="pf-field"><input type="text" placeholder="ALi TUFAN"></div>
                           </div>
                           <div class="col-lg-12">
                              <span class="pf-title">Email</span>
                              <div class="pf-field"><input type="text" placeholder="ALi TUFAN"></div>
                           </div>
                           <div class="col-lg-12">
                              <span class="pf-title">Subject</span>
                              <div class="pf-field"><input type="text" placeholder="ALi TUFAN"></div>
                           </div>
                           <div class="col-lg-12">
                              <span class="pf-title">Message</span>
                              <div class="pf-field"><textarea></textarea></div>
                           </div>
                           <div class="col-lg-12"><button type="submit">Send</button></div>
                        </div>
                     </form>
                  </div>
               </div>
               <div class="col-lg-6 column">
                  <div class="contact-textinfo style2">
                     <h3>JobHunt Office</h3>
                     <ul>
                        <li><i class="la la-map-marker"></i><span>Jobify Inc. 555 Madison Avenue, Suite F-2 Manhattan, New York 10282 </span></li>
                        <li><i class="la la-phone"></i><span>Call Us : 0934 343 343</span></li>
                        <li><i class="la la-fax"></i><span>Fax : 0934 343 343</span></li>
                        <li><i class="la la-envelope-o"></i><span>Email : <a href="https://grandetest.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="157c7b737a557f7a777d607b613b767a78">[email&nbsp;protected]</a></span></li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\job_vacancy\resources\views/Contact.blade.php ENDPATH**/ ?>