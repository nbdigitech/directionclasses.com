<?php $__env->startSection('headerid'); ?>
gradient
<?php $__env->stopSection(); ?>
<?php $__env->startSection('MainSection'); ?>
<style type="text/css">
.card-head{
   text-align: left;
   cursor: none;
   background-color:#273244;
   color:white;
   padding:10px;
   margin-top: -10px;
   font-weight: normal;
}

#aler{
   width:400px;
   float: right;
}

#exampleModalLabel{
   text-align: center;
   margin-top: 60px;
}

#mydesign input, #select{
   margin-top: 30px;
}

#c{
   margin-right: 90px
}

#d{
   margin-right: 20px
}

#exampleModalLabel i{
   color:#F9D79F;
   font-weight: normal;
   font-size: 40px;
   border:2px solid #F9D79F;
   border-radius: 50px;
   padding:30px;
   font-weight: normal;
}

.modal-body h5{
   text-align: center;
}

.model-body .footer{
   text-align: center;
   margin-bottom: 30px
   margin-top:30px;
}

.footer button{
   padding-left: 30px; padding-right: 30px;
   padding-top:10px;
   padding-bottom:10px;

}

.modal-body h2{
   text-align: center;
   margin-top: 10px;
   font-weight: bold;
   color:#595959;
}

#list{
   font-size: 15px;
}

.input-group #input-group-addon{
   width: 40px;
}

.fa-mobile{
   font-size: 20px;
   margin-top: 10px;
}

.input-group textarea{
   padding-top: 20px;
}

.fa-location-arrow{
   margin-top:20px;
}

 .fa-phone{
   margin-top: 50px;
}

@media(max-width: 768px){
   #c{
   margin-right: 5px;

}

#aler{
   width:100%;
}

#d{
   margin-right: 5px
}
}

</style>
   <div class="theme-layout" id="scrollup">
   <br><br>
   <section class="overlape">
      <div class="container">
         <form action="#" method="get">
            <div class="row">
               <div class="col-lg-7 col-md-5 col-sm-12 col-xs-12" style="margin-top: 20px;">
                  <div class="job-field">
                     <input type="text" style="border:1px solid black;" placeholder="Job title, keywords or company name" />
                     <i class="la la-keyboard-o"></i>
                  </div>
               </div>
               <div class="col-lg-4 col-md-5 col-sm-12 col-xs-12" style="margin-top: 20px;">
                  <div class="job-field">
                     <input type="text" style="width: 100%; border:1px solid black;" placeholder="Search Job in Your Location">
                        
                     <i class="la la-map-marker"></i>
                  </div>
               </div>
               <div class="col-lg-1 col-md-2 col-sm-12 col-xs-12" style="margin-top: 20px;">
                  <button type="submit" style="background: #fb236a; border-radius: 5px; height: 60px;  width: 100%;"><i class="la la-search" style="font-size: 18px;"></i></button>
               </div>
            </div>
         </form>
      </div>
   </section>
 <section>
      <div class="block">
         <div class="container">
             <div class="row">
               <div class="col-lg-12">
              
                  <div class="job-grid-sec">
                     <div class="row">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                           <div class="job-grid border">
                              <p style="float: right; margin-bottom: 50px;">Post Date :- 25-05-2019</p>
                              <a style="border:none;" href="<?php echo e(url('FindJob/Details',$row->id)); ?>">
                              <div class="job-title-sec">
                                 <div class="c-logo" style="margin-top: -30px;"> <img src="<?php echo e(url('/')); ?>/public/assets/uploads/<?php echo e($row->Logo); ?>" alt="" /> </div>
                                 <h3><a href="#" title=""><?php echo e($row->JobTitle); ?></a></h3>
                                 <span><?php echo e($row->CompanyName); ?></span>
                              </div>
                              </a>
                              <span class="job-lctn"><?php echo e($row->City); ?></span>
                              <?php if(Auth::user()): ?>
                              <form action="<?php echo e(route('Job/Apply/Session')); ?>" method="post"><?php echo e(csrf_field()); ?>

                                 <input type="hidden" name="JobPostId" value="<?php echo e($row->id); ?>">
                              <button  type="submit" style=" margin-top: 10px; border-radius: 10px; background: #fb236a;color:white;">APPLY NOW</button>
                              </form>
                              <?php else: ?>
                             
                              <a class="signup-popup" href="#" style=" margin-top: 10px; border-radius: 10px; background: #fb236a;color:white;">APPLY NOW</a>
                            
                              <?php endif; ?>

                           </div><!-- JOB Grid -->
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </div>
                  </div>
                  <div class="pagination">
                    <?php echo e($data->links()); ?>

                  </div><!-- Pagination -->
               </div>
             </div>
         </div>
      </div>
   </section>
</div>

<?php if(session()->has('success')): ?>
<div class="alert alert-success fixed-top" id="aler" role="alert" style="color:white;background: #3BC761;border:none;padding-top:20px; padding-bottom:20px;">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close" ><span aria-hidden="true">&times;</span></button>
  <strong style="color:white">Success!</strong> <?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\job_vacancy\resources\views/FindJob.blade.php ENDPATH**/ ?>