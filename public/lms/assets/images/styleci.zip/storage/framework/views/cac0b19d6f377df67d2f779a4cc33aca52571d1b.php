<?php $__env->startSection('headerid'); ?>
gradient
<?php $__env->stopSection(); ?>
<?php $__env->startSection('MainSection'); ?>
   <div class="alert-box success">Changes saved successfull !!!</div>
         <section>
            <div class="block no-padding  gray">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12">
                        <div class="inner2">
                           <div class="inner-title2">
                              <h3>Job Post</h3>
                              <span>Keep up to date with the latest news</span>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
  <section>
      <div class="block no-padding">
         <div class="container">
             <div class="row no-gape">
               <div class="col-lg-12 column">
                  <div class="padding-left">
                     <div class="profile-form-edit">
                        <form action="<?php if(isset($edit->id)): ?> <?php echo e(route('Profile/JobPost/Update')); ?> <?php else: ?> <?php echo e(route('Profile/JobPost/Store')); ?> <?php endif; ?>" method="post" enctype="multipart/form-data">
                           <?php if(isset($edit->id)): ?>
                           <input type="hidden" name="Update" value="<?php echo e($edit->id); ?>">
                            <?php endif; ?>
                           <?php echo e(csrf_field()); ?>

                           <div class="row">
                              <div class="col-lg-12">
                                 <span class="pf-title">Job Title</span>
                                 <div class="pf-field">
                                    <input type="text" placeholder="Designer" name="JobTitle" required value="<?php if(isset($edit->id)): ?> <?php echo e($edit->JobTitle); ?> <?php endif; ?>" />
                                 </div>
                              </div>
                              <div class="col-lg-12">
                                 <span class="pf-title">Description</span>
                                 <div class="pf-field">
                                    <textarea name="JobDescription">
                                       <?php if(isset($edit->id)): ?> 
                                       <?php echo e($edit->JobDescription); ?>

                                       <?php else: ?>
                                       Spent several years working on sheep on Wall Street. Had moderate success investing in Yugos on Wall Street. Managed a small team buying and selling pogo sticks for farmers. Spent several years licensing licorice in West Palm Beach, FL. Developed severalnew methods for working with banjos in the aftermarket. Spent a weekend importing banjos in West Palm Beach, FL.In this position, the Software Engineer ollaborates with Evention's Development team to continuously enhance our current software solutions as well as create new solutions to eliminate the back-office operations and management challenges present
                                     <?php endif; ?></textarea>
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">Contact Email</span>
                                 <div class="pf-field">
                                    <input type="text" name="Email" value="<?php if(isset($edit->id)): ?> <?php echo e($edit->Email); ?> <?php endif; ?>" />
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">Contact Number</span>
                                 <div class="pf-field">
                                    <input type="text" name="Mobile"  value="<?php if(isset($edit->id)): ?> <?php echo e($edit->Mobile); ?> <?php endif; ?>" />
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">Job Type</span>
                                 <div class="pf-field">
                                    <select required name="JobType" data-placeholder="Please Select Specialism" class="chosen">
                                       <option value="Full Time" <?php if(isset($edit->id)): ?> <?php if($edit->JobType=='Full Time'): ?> Selected <?php endif; ?> <?php endif; ?>>Full Time</option>
                                       <option value="Half Time" <?php if(isset($edit->id)): ?> <?php if($edit->JobType=='Half Time'): ?> Selected <?php endif; ?> <?php endif; ?>>Half Time</option>
                                       <option value="Freelance" <?php if(isset($edit->id)): ?> <?php if($edit->JobType=='Freelance'): ?> Selected <?php endif; ?> <?php endif; ?>>Freelance</option>
                                    </select>
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">Category</span>
                                 <div class="pf-field">
                                    <select required data-placeholder="Please Select Specialism" name="Category" class="chosen">
                                       <option value="Web Development" <?php if(isset($edit->id)): ?> <?php if($edit->Category=='Web Development'): ?> Selected <?php endif; ?> <?php endif; ?>>Web Development</option>
                                       <option value="Web Designing" <?php if(isset($edit->id)): ?> <?php if($edit->Category=='Web Designing'): ?> Selected <?php endif; ?> <?php endif; ?>>Web Designing</option>
                                       <option value="Content Writer" <?php if(isset($edit->id)): ?> <?php if($edit->Category=='Content Writer'): ?> Selected <?php endif; ?> <?php endif; ?>>Content Writer</option>
                                       <option value="Graphics Designer" <?php if(isset($edit->id)): ?> <?php if($edit->Category=='Graphics Designer'): ?> Selected <?php endif; ?> <?php endif; ?>>Graphics Designer</option>
                                    </select>
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">Offerd Salary</span>
                                 <div class="pf-field">
                                    <input type="text" name="OfferedSallary" />
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">Experience</span>
                                 <div class="pf-field">
                                    <select data-placeholder="Please Select Specialism" name="Experience" class="chosen">
                                       <option>0-1 Year </option>
                                       <option>1-2 Year </option>
                                       <option>2-3 Year </option>
                                       <option>4-1 Year </option>
                                       <option>5-6 Year </option>
                                       <option>6-7 Year </option>
                                       <option>7-8 Year </option>
                                       <option>8-9 Year </option>
                                       <option>9-10 Year </option>
                                    </select>
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">Gender</span>
                                 <div class="pf-field">
                                    <select required data-placeholder="Please Select Specialism" class="chosen">
                                       <option>Male</option>
                                       <option>Female</option>
                                       <option>Male - Female Both</option>
                                    </select>
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">Qualification</span>
                                 <div class="pf-field">
                                    <select required data-placeholder="Please Select Specialism" class="chosen">
                                       <option>10th Passout </option>
                                       <option>12th Passout</option>
                                       <option>Graduate</option>
                                       <option>Post Graduate</option>
                                    </select>
                                 </div>
                              </div>
                              <div class="col-lg-12">
                                 <span class="pf-title">Application Deadline Date</span>
                                 <div class="pf-field">
                                    <input type="text" placeholder="01.11.207" name="ApplicationDeadline"  class="form-control datepicker" />
                                 </div>
                              </div>
                              <div class="col-lg-12">
                                 <span class="pf-title">Skill Requirments</span>
                                 <div class="pf-field">
                                    <ul class="tags">
                                         <li class="addedTag">Photoshop<span onclick="$(this).parent().remove();" class="tagRemove">x</span><input type="hidden" name="tags[]" value="Web Deisgn"></li>
                                          <li class="tagAdd taglist">  
                                              <input type="text" id="search-field">
                                          </li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">Company Name</span>
                                 <div class="pf-field">
                                   <input type="text" required placeholder="Company Name" name="CompanyName" />
                                 </div>
                              </div>

                               <div class="col-lg-6">
                                 <span class="pf-title">Company Logo</span>
                                 <div class="pf-field">
                                   <input type="file" required name="Logo"/>
                                 </div>
                              </div>

                               <div class="col-lg-6">
                                 <span class="pf-title">City</span>
                                 <div class="pf-field">
                                   <input type="text" required placeholder="City" name="City" />
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <span class="pf-title">State</span>
                                 <div class="pf-field">
                                    <select required name="State" data-placeholder="Please Select Specialism" class="chosen">
                                       <option>Chhattisgarh</option>
                                       
                                    </select>
                                 </div>
                              </div>
                              <div class="col-lg-12">
                                 <span class="pf-title">Complete Address</span>
                                 <div class="pf-field">
                                    <textarea>Collins Street West, Victoria 8007, Australia.</textarea>
                                 </div>
                                 <button type="submit" style="width: 100%; margin-bottom: 20px;"> Submit Now</button>
                              </div>
                              
                           </div>
                        </form>
                     </div>
                    
                  </div>
               </div>
             </div>
         </div>
      </div>
   </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\job_vacancy\resources\views/JobPost.blade.php ENDPATH**/ ?>