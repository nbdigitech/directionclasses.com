<?php $__env->startSection('headerid'); ?>
stick-top forsticky
<?php $__env->stopSection(); ?>
<?php $__env->startSection('MainSection'); ?>
<section>
	<style type="text/css">
		#cll select{
				height: 50px;
			}
			#cll input{
				height: 50px;
				font-size: 16px;
			}
			#cll{
				margin-top: 30px;
			}
			#form_sec{
				margin-top: -60px;
			}
		@media(max-width: 768px){
			#cll{
				margin-top: 30px;
			}
			#form_sec{
				margin-top: -20px;
			}
		}
	</style>
		<div class="block no-padding">
			<div class="container fluid">
				<div class="row">
					<div class="col-lg-12">
						<div class="main-featured-sec">
							<div class="new-slide">
								<img src="<?php echo e(url('/')); ?>/public/assets/images/resource/vector-1.png">
							</div>
							<div class="job-search-sec">
								<div class="job-search">
									<h3>Search Job In Your City</h3>
									<span>Find Jobs, Employment & Career Opportunities</span>
									<form action="<?php echo e(route('FindJob')); ?>" method="get">
										<?php echo e(csrf_field()); ?>

										<div class="row">
											<div class="col-lg-7 col-md-5 col-sm-12 col-xs-12">
												<div class="job-field">
													<input type="text" name="Job" placeholder="Job title, keywords or company name" />
													<i class="la la-keyboard-o"></i>
												</div>
											</div>
											<div class="col-lg-4 col-md-5 col-sm-12 col-xs-12">
												<div class="job-field">
													<select name="Location" data-placeholder="City, province or region" class="chosen-city">
														<option>Raipur </option>
														<option>Bhilai</option>
														<option>Durg</option>
														<option>Bilaspur</option>
													</select>
													<i class="la la-map-marker"></i>
												</div>
											</div>
											<div class="col-lg-1 col-md-2 col-sm-12 col-xs-12">
												<button type="submit"><i class="la la-search"></i></button>
											</div>
										</div>
									</form>
								
								</div>
							<?php if(!Auth::user()): ?>
								<center><a class="signup-popup" href="#" style="background: #FB236A; color:white; padding:15px; padding-left: 100px; padding-right: 100px; border-radius: 5px; font-weight: bold;"> Login Here</a></center>
							<?php endif; ?>
							</div>
						
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<section id="form_sec">
		<div class="block">
			<div class="container">

				<form action="<?php echo e(route('Form/Store')); ?>" method="post">
				<div class="row" style="box-shadow: 0 10px 20px rgba(0,0,0,0.19), 0 6px 6px rgba(0,0,0,0.23); padding:30px;">
					<div class="col-sm-12">
						<h5 style="text-align: center; font-weight: bold;">Get Free Counselling</h5>
					</div>
					<?php echo e(csrf_field()); ?>

						<div class="col-md-4" id="cll">
							<input required placeholder="Full Name..." name="Name" class="form-control" type="text">
						</div>

						<div class="col-md-4" id="cll">
							<input required placeholder="Email Address..." name="Email" class="form-control" type="email">
						</div>

						<div class="col-md-4" id="cll">
							<input required placeholder="Mobile Number..." name="Mobile" class="form-control" type="number">
						</div>

						<div class="col-md-3" id="cll">
							<input required placeholder="City..." name="City" class="form-control" type="text">
						</div>

						<div class="col-md-3" id="cll">
							<input required placeholder="Date..." name="Date" class="form-control" type="date">
						</div>

						<div class="col-md-3" id="cll">
							<input required placeholder="ScheduleTime..." name="Time" class="form-control" type="time">
						</div>
						
						<div class="col-md-3" id="cll"><center>
							<button type="submit" class="btn btn-success" style="background:#fb236a; border:none; width: 100%;margin:auto;float: left; height: 50px;">Enquire Now</button></center>
						</div>
					</form>
				</div><br><br>
				<div class="row">
					<div class="col-lg-12">
						<center><h2 style="font-weight: bold;">Consultants</h2></center><br>
					</div>
				</div>
				 <div class="row">
				 	<div class="col-lg-12">
				 		<div class="blog-sec">
							<div class="row" id="masonry">
								<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
									<div class="my-blog">
										<div class="blog-thumb">
											<a href="#" title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/bhuwnesh.png" alt=""  style="height: 350px;" /></a>
											<div class="blog-metas">
												Bhuwnesh Shrivastava 
											</div>
										</div>
										<div class="blog-details">
											<h3><a href="#" title="" style="font-size: 15px;">Arise and Awake

Founder</a></h3>
											<p>PGDDA -IIITB,
Digital Marketing from
IIM Bangalore | B.E (ET&T) </p>
											
										</div>
									</div>
								</div>
								<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
									<div class="my-blog">
										<div class="blog-thumb">
											<a  title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/kaustubh.jpeg" style="height: 350px;" alt="" /></a>
											<div class="blog-metas">
												Kaustubh Sharma
											</div>
										</div>
										<div class="blog-details">
											<h3><a  title="" style="font-size: 15px;">Communication and Language (English)</a></h3>
											<p>BBA Graduate. M-Lit English.</p>
											
										</div>
									</div>
								</div>
								<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
									<div class="my-blog">
										<div class="blog-thumb">
											<a href="#" title=""><img style="height: 350px;" src="<?php echo e(url('/')); ?>/public/assets/images/Subhayu.jpeg" alt="" /></a>
											<div class="blog-metas">
												Dr. Subhayu Sikdar
											</div>
										</div>
										<div class="blog-details">
											<h3><a style="font-size: 15px;" title="">International Studies</a></h3>
						<p>Mentor (International Studies) MD Physician</p>
										</div>
									</div>
								</div>
							<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
									<div class="my-blog">
										<div class="blog-thumb">
											<a href="#" title=""><img style="height: 350px;" src="<?php echo e(url('/')); ?>/public/assets/images/harsh-dubey.jpg" alt="" /></a>
											<div class="blog-metas">
												Harsh Dubey
											</div>
										</div>
										<div class="blog-details">
											<h3><a style="font-size: 15px;" title="">Communication and
Language (Hindi)
</a></h3>
											<p>Hindi Journalism (IIMC, New Delhi) M.A. Mass Communication</p>
											
										</div>
									</div>
								</div>
					</div>
				 </div>
			</div>
		</div>
	</section>
	<section>
		<div class="block double-gap-top double-gap-bottom">
			<div data-velocity="-.1" style="background: url(<?php echo e(url('/')); ?>/public/assets/images/resource/parallax1.jpg) repeat scroll 50% 422.28px transparent;" class="parallax scrolly-invisible layer color"></div><!-- PARALLAX BACKGROUND IMAGE -->
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="simple-text-block">
							<h3>Make a Difference with Your Online Resume!</h3>
							<span>Your resume in minutes with Job Portal resume assistant is ready!</span>
							<a class="signup-popup" href="#" title="">Create an Account</a>
						</div>
					</div>
				</div>
			</div>	
		</div>
	</section>

	<section>
		<div class="block">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="heading">
							<h2>Current Jobs</h2>
						</div>
						<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="job-listings-sec">
							<div class="job-listing">
								<div class="job-title-sec">
									<div class="c-logo"> <img src="<?php echo e(url('/')); ?>/public/assets/uploads/<?php echo e($row->Logo); ?>" style="width: 60px; height: 60px" alt="" /> </div>
									<h3><a href="<?php echo e(url('FindJob/Details',$row->id)); ?>" title=""><?php echo e($row->JobTitle); ?></a></h3>
									<span><?php echo e($row->Date); ?></span>
								</div>
								<span class="job-lctn"><i class="la la-map-marker"></i><?php echo e($row->City); ?></span>
								<span class="job-is ft"><?php echo e($row->JobType); ?></span>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					
			</div>
		</div>
	</section>
	<section>
		<!-- <div class="block">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="heading">
							<h2>Companies We've Helped</h2>
							<span>Some of the companies we've helped recruit excellent applicants over the years.</span>
						</div>
						<div class="comp-sec">
							<div class="company-img">
								<a href="#" title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/resource/cc1.jpg" alt="" /></a>
							</div>
							<div class="company-img">
								<a href="#" title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/resource/cc2.jpg" alt="" /></a>
							</div>
							<div class="company-img">
								<a href="#" title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/resource/cc3.jpg" alt="" /></a>
							</div>
							<div class="company-img">
								<a href="#" title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/resource/cc4.jpg" alt="" /></a>
							</div>
							<div class="company-img">
								<a href="#" title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/resource/cc5.jpg" alt="" /></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div> -->
	</section>

	<!-- <section>
		<div class="block">
			<div data-velocity="-.1" style="background: url(<?php echo e(url('/')); ?>/public/assets/images/resource/parallax3.jpg) repeat scroll 50% 422.28px transparent;" class="parallax scrolly-invisible no-parallax"></div>
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="heading">
							<h2>Quick Career Tips</h2>
							<span>Found by employers communicate directly with hiring managers and recruiters.</span>
						</div>
						<div class="blog-sec">
							<div class="row">
								<div class="col-lg-4">
									<div class="my-blog">
										<div class="blog-thumb">
											<a href="#" title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/resource/b1.jpg" alt="" /></a>
											<div class="blog-metas">
												<a href="#" title="">March 29, 2017</a>
												<a href="#" title="">0 Comments</a>
											</div>
										</div>
										<div class="blog-details">
											<h3><a href="#" title="">Attract More Attention Sales And Profits</a></h3>
											<p>A job is a regular activity performed in exchange becoming an employee, volunteering, </p>
											
										</div>
									</div>
								</div>
								<div class="col-lg-4">
									<div class="my-blog">
										<div class="blog-thumb">
											<a href="#" title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/resource/b2.jpg" alt="" /></a>
											<div class="blog-metas">
												<a href="#" title="">March 29, 2017</a>
												<a href="#" title="">0 Comments</a>
											</div>
										</div>
										<div class="blog-details">
											<h3><a href="#" title="">11 Tips to Help You Get New Clients</a></h3>
											<p>A job is a regular activity performed in exchange becoming an employee, volunteering, </p>
											
										</div>
									</div>
								</div>
								<div class="col-lg-4">
									<div class="my-blog">
										<div class="blog-thumb">
											<a href="#" title=""><img src="<?php echo e(url('/')); ?>/public/assets/images/resource/b3.jpg" alt="" /></a>
											<div class="blog-metas">
												<a href="#" title="">March 29, 2017</a>
												<a href="#" title="">0 Comments</a>
											</div>
										</div>
										<div class="blog-details">
											<h3><a href="#" title="">An Overworked Newspaper Editor</a></h3>
											<p>A job is a regular activity performed in exchange becoming an employee, volunteering, </p>
											
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section> -->

	<section>
		<div class="block no-padding">
			<div class="container fluid">
				<div class="row">
					<div class="col-lg-12">
						<div class="simple-text">
							<h3>Get a question?</h3>
							<span>We're here to help. Check out our FAQs, send us an email or call us at - 9827900742</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php if(session()->has('success')): ?>
<div class="alert alert-success fixed-top" id="aler" role="alert" style="color:white;background: #3BC761;border:none;padding-top:20px; padding-bottom:20px;">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close" ><span aria-hidden="true">&times;</span></button>
  <strong style="color:white">Success!</strong> <?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\job_vacanc\resources\views/Index.blade.php ENDPATH**/ ?>