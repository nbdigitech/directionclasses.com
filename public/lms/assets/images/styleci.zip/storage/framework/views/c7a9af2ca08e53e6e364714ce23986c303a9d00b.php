<?php $__env->startSection('headerid'); ?>
gradient
<?php $__env->stopSection(); ?>
<?php $__env->startSection('MainSection'); ?>
<div class="theme-layout" id="scrollup">
   <section>
      <div class="block no-padding  gray">
         <div class="container">
            <div class="row">
               <div class="col-lg-12">
                  <div class="inner2">
                     <div class="inner-title2">
                        <h3>Contact</h3>
                        <span>feel free to contact with us</span>
                     </div>
                     <div class="page-breacrumbs">
                        <ul class="breadcrumbs">
                           <li><a href="<?php echo e(route('Index')); ?>">Home</a></li>
                           <li>Contact</li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <section>
      <div class="block">
         <div class="container">
            <div class="row">
               <div class="col-lg-6 column">
                  <div class="contact-form">
                     <h3>Keep In Touch</h3>
                     <form>
                        <div class="row">
                           <div class="col-lg-12">
                              <span class="pf-title">Full Name</span>
                              <div class="pf-field"><input type="text" placeholder="Your Name"></div>
                           </div>
                           <div class="col-lg-12">
                              <span class="pf-title">Email</span>
                              <div class="pf-field"><input type="text" placeholder="Enter Email id"></div>
                           </div>
                           <div class="col-lg-12">
                              <span class="pf-title">Subject</span>
                              <div class="pf-field"><input type="text" placeholder="Type Subject"></div>
                           </div>
                           <div class="col-lg-12">
                              <span class="pf-title">Message</span>
                              <div class="pf-field"><textarea></textarea></div>
                           </div>
                           <div class="col-lg-12"><button type="submit">Send</button></div>
                        </div>
                     </form>
                  </div>
               </div>
               <div class="col-lg-6 column">
                  <div class="contact-textinfo style2">
                     <h3>Job Vacancy Address:</h3>
                     <ul>
                        <li><i class="la la-map-marker"></i><span>36 INC, 3rd Floor, City Central Mall,Raipur (C.G) </span></li>
                        <li><i class="la la-phone"></i><span>Call Us : 097546 00742</span></li>
                       
                        <li><i class="la la-envelope-o"></i><span>Email : <a href="https://grandetest.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="157c7b737a557f7a777d607b613b767a78">support@nbdigitech.com</a></span></li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\job_vacanc\resources\views/Contact.blade.php ENDPATH**/ ?>