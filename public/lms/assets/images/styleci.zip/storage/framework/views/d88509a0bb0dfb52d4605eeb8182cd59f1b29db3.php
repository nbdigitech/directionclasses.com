<?php $__env->startSection('MainSection'); ?>
  <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                  <div class="card-header card-header-primary card-header-icon" style="margin-top: -15px;">
                  <div style="background-color: #DE3743  ; padding: 10px; padding-left: 16px; padding-top:16px; border-radius: 3px;" style="width: 100%;">
                    <h4>Enquiry Form
                      </h4>
                  </div>

                </div>
                <div class="card-body">
                  <div class="toolbar">
                  </div>
                  <div class="material-datatables">
                    <table id="datatables" class="table table-no-bordered" cellspacing="0" width="100%" style="width:100%">
                      <thead>
                        <tr>
                          <th style="font-weight: bold;">#</th>
                          <th style="font-weight: bold;">Name</th>
                          <th style="font-weight: bold;">Email</th>
                          <th style="font-weight: bold;">Mobile</th>
                          <th style="font-weight: bold;">SDate</th>
                          <th style="font-weight: bold;">STime</th>
                          <th style="font-weight: bold;">Delete</th>
               
                        </tr>
                      </thead>
                      <tbody>
                     <?php $i = 1; ?>
                     <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                          <td><?php echo e($i++); ?></td>
                          <td><?php echo e($row->Name); ?></td>
                          <td><?php echo e($row->Email); ?></td>
                          <td><?php echo e($row->Mobile); ?></td>
                          <td><?php echo e($row->Date); ?></td>
                          <td><?php echo e($row->Time); ?></td>
                         <td>
                              <button  onclick="delete_function('<?php echo e($row->id); ?>')" data-toggle="modal" data-target="#myModal" title="Click To View Details" type="button" class="btn btn-success">
                                Delete
                              </button>
                            
                           </td>
                          </td>
                        </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                  </div>
                </div>
                <!-- end content-->
              </div>
              <!--  end card  -->
            </div>
            <!-- end col-md-12 -->
          </div>
          <!-- end row -->
        </div>
      </div>
</div>

<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header"  style="background-color: #DE3743; color:white;">
        <h4 class="modal-title" style="margin-top: -10px; margin-bottom: 10px;">Are You Sure Delete It ?</h4>
        <button type="button" class="close" data-dismiss="modal" style="color:white;">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body" style="text-align: center; padding-top: 50px;">
        If you are delete it. you can't get it after
      </div>

      <!-- Modal footer -->
      <div class="row" style="padding-bottom: 50px;">
        <div class="col-sm-2"></div>
        <div class="col-sm-4">
          <form action="<?php echo e(route('Admin/EnquiryDetails/Delete')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" id="delete_id" name="Delete">

          <button type="submit" class="btn btn-success" style="color:white; margin-right: 50px; width: 100%;">Yes</button>
          </form>
        </div>
        <div class="col-sm-4">
          <button type="button" class="btn btn-danger" data-dismiss="modal" style="color:white; width: 100%; background-color: #DE3743;">No</button>
        </div>
        <div class="col-sm-2"></div>
      </div>
    </div>
  </div>
</div>

  <script type="text/javascript">
    function delete_function(id){
      document.getElementById('delete_id').value = id;
    }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\job_vacanc\resources\views/Admin/Forms/Index.blade.php ENDPATH**/ ?>