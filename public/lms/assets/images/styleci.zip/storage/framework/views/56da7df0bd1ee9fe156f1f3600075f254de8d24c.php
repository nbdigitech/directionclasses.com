<?php $__env->startSection('headerid'); ?>
gradient
<?php $__env->stopSection(); ?>
<?php $__env->startSection('MainSection'); ?>
   <div class="theme-layout" id="scrollup">
   <br><br>
   <section class="overlape">
      <div class="container">
         <form action="<?php echo e(route('FindJob')); ?>" method="post">
            <div class="row">
               <div class="col-lg-7 col-md-5 col-sm-12 col-xs-12" style="margin-top: 20px;">
                  <div class="job-field">
                     <input type="text" style="border:1px solid black;" placeholder="Job title, keywords or company name" />
                     <i class="la la-keyboard-o"></i>
                  </div>
               </div>
               <div class="col-lg-4 col-md-5 col-sm-12 col-xs-12" style="margin-top: 20px;">
                  <div class="job-field">
                     <input type="text" style="width: 100%; border:1px solid black;" placeholder="Search Job in Your Location">
                        
                     <i class="la la-map-marker"></i>
                  </div>
               </div>
               <div class="col-lg-1 col-md-2 col-sm-12 col-xs-12" style="margin-top: 20px;">
                  <button type="submit" style="background: #fb236a; border-radius: 5px; height: 60px;  width: 100%;"><i class="la la-search" style="font-size: 18px;"></i></button>
               </div>
            </div>
         </form>
      </div>
   </section>
 <section>
      <div class="block">
         <div class="container">
             <div class="row">
               <div class="col-lg-12">
              
                  <div class="job-grid-sec">
                     <div class="row">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                           <div class="job-grid border">
                              <p style="float: right; margin-bottom: 50px;">Post Date :- 25-05-2019</p>
                              <a style="border:none;" href="<?php echo e(url('FindJob/Details',$row->id)); ?>">
                              <div class="job-title-sec">
                                 <div class="c-logo" style="margin-top: -30px;"> <img src="<?php echo e(url('/')); ?>/public/assets/uploads/<?php echo e($row->Logo); ?>" alt="" /> </div>
                                 <h3><a href="#" title=""><?php echo e($row->JobTitle); ?></a></h3>
                                 <span><?php echo e($row->CompanyName); ?></span>
                                
                              </div>
                              </a>
                              <span class="job-lctn"><?php echo e($row->City); ?></span>
                              <?php if(Auth::user()): ?>
                              <form action="<?php echo e(route('Job/Apply/Session')); ?>" method="post"><?php echo e(csrf_field()); ?>

                                 <input type="hidden" name="JobPostId" value="<?php echo e($row->id); ?>">
                              
                              <button  type="submit" style=" margin-top: 10px; border-radius: 10px; background: #fb236a;color:white;">APPLY NOW</button>
                              </form>
                              <?php else: ?>
                             
                              <a class="signup-popup" href="#" style=" margin-top: 10px; border-radius: 10px; background: #fb236a;color:white;">APPLY NOW</a>
                            
                              <?php endif; ?>

                           </div><!-- JOB Grid -->
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </div>
                  </div>
                  <div class="pagination">
                    <?php echo e($data->links()); ?>

                  </div><!-- Pagination -->
               </div>
             </div>
         </div>
      </div>
   </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\job_vacancy\resources\views/FindJob.blade.php ENDPATH**/ ?>