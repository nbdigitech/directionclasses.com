<style type="text/css">
    @media(max-width:768px){
        	.profile-sidebar{
		    margin-top:100px;
		}
    }
	@media(min-width: 1000px){
		#m{
			display: none;
		}
	}
</style>
<footer style="z-index: 0;">
		<div class="block">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 column">
						<div class="widget">
							<div class="about_widget">
								<div class="logo">
									<a href="<?php echo e(route('Index')); ?>" style="color:white; font-size:30px;">Job Vacancy</a>
								</div>
								<span>Nb Digital Technoogies, Near Fafadih Chowk, Raipuur</span>
								<span>9827900742</span>
							
								<div class="social">
									<a href="#"><i class="fa fa-facebook"></i></a>
									<a href="#"><i class="fa fa-twitter"></i></a>
									<a href="#"><i class="fa fa-linkedin"></i></a>
									<a href="#"><i class="fa fa-pinterest"></i></a>
									<a href="#"><i class="fa fa-behance"></i></a>
								</div>
							</div><!-- About Widget -->
						</div>
					</div>
					<div class="col-lg-4 column">
						<div class="widget">
							<h3 class="footer-title">Frequently Asked Questions</h3>
							<div class="link_widgets">
								<div class="row">
									<div class="col-lg-6">
										<a href="#"style="z-index: 0;">Privacy & Seurty </a>
										<a href="#">Terms of Serice</a>
										<a href="#">Communications </a>
										<a href="#">Referral Terms </a>
										<a href="#">Lending Licnses </a>
										<a href="#">Disclaimers </a>	
									</div>
									<div class="col-lg-6">
										<a href="#">Support </a>
										<a href="#">How It Works </a>
										<a href="#">For Employers </a>
										<a href="#">Underwriting </a>
										<a href="#">Contact Us</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-2 column">
						<div class="widget">
							<h3 class="footer-title">Find Jobs</h3>
							<div class="link_widgets">
								<div class="row">
									<div class="col-lg-12">
										<a href="#">US Jobs</a>	
										<a href="#">Canada Jobs</a>	
										<a href="#">UK Jobs</a>	
										<a href="#">Emplois en Fnce</a>	
										<a href="#">Jobs in Deuts</a>	
										<a href="#">Vacatures China</a>	
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3 column">
						<div class="widget">
							<div class="download_widget">
								<a href="#"><img src="<?php echo e(url('/')); ?>/public/assets/images/resource/dw1.png" alt="" /></a>
								<a href="#"><img src="<?php echo e(url('/')); ?>/public/assets/images/resource/dw2.png" alt="" /></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="bottom-line">
			<span>© 2018 Jobhunt All rights reserved. Design by Creative Layers</span>
			<a href="#scrollup" class="scrollup"><i class="la la-arrow-up"></i></a>
		</div>
	</footer>
<?php if(Auth::user()): ?>
	<div class="profile-sidebar">
	<span class="close-profile"><i class="la la-close"></i></span>
	<div class="can-detail-s">
		<div class="cst"><img src="<?php echo e(Auth::user()->pic); ?>" alt="" /></div>
		<h3><?php echo e(Auth::user()->name); ?></h3>
		<span><i>Role</i> <?php echo e(Auth::user()->role); ?></span>
		<p><i class="la la-envelope"></i><?php echo e(Auth::user()->email); ?></p>
	</div>
	<div class="tree_widget-sec">
		<ul>
			<?php if(Auth::user()): ?> <?php if(Auth::user()->role=='Candidate'): ?>
			<li><a href="<?php echo e(route('Profile')); ?>"><i class="la la-file-text"></i>My Profile</a></li><br><br>
			
			<?php elseif(Auth::user()->role=='Employer'): ?>
			<li><a href="<?php echo e(route('Profile')); ?>"><i class="la la-file-text"></i>Company Profile</a></li><br><br>
			<li><a href="<?php echo e(route('Profile/JobPost/List')); ?>"><i class="la la-file-text"></i>Posted Jobs</a></li><br><br>
			<li><a href="<?php echo e(route('Profile/AppliedCandidates')); ?>"><i class="la la-file-text"></i>Applied Candidates</a></li><br><br>
			<li>
			<?php endif; ?>
			<?php endif; ?>
			<form action="<?php echo e(route('logout')); ?>" method="post">
				<?php echo e(csrf_field()); ?>

				<button type="submit" style="background: none;color:gray; float:left; margin-left: -10px; font-size: 14px;"><i class="la la-unlink" style="margin-left: -15px; margin-right: 20px;"></i>Logout</button>
			</form>
			<br><br><hr></li>
			<?php if(Auth::user()): ?>
               <?php if(Auth::user()->role=='Employer'): ?>
               <a class="post-job-btn" href="<?php echo e(route('Profile/JobPost')); ?>"><i class="la la-plus"></i>Post Jobs</a>
               <?php endif; ?> <?php endif; ?> <br>
			<li id="m"><a href="<?php echo e(route('Index')); ?>"><i class="la la-briefcase"></i>Home</a></li>
			<li id="m"><a href="<?php echo e(route('About')); ?>"><i class="la la-money"></i>About</a></li>
			<li id="m"><a href="<?php echo e(route('FindJob')); ?>"><i class="la la-paper-plane"></i>Find Job</a></li>
			<li id="m"><a href="<?php echo e(route('Contact')); ?>"><i class="la la-user"></i>Contact</a></li>
			
		</ul>
	</div>
</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\job_vacancy\resources\views/layouts/Footer.blade.php ENDPATH**/ ?>