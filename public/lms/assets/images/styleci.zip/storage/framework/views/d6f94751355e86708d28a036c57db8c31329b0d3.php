<?php $__env->startSection('MainSection'); ?>
	<div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                  <div class="card-header card-header-primary card-header-icon" style="margin-top: -15px;">
                  <div style="background-color: #DE3743  ; padding: 10px; padding-left: 16px; padding-top:16px; border-radius: 3px;" style="width: 100%;">
                    <h4>Manage Employers
                      </h4>
                  </div>

                </div>
                <div class="card-body">
                 <div class="row">
                   <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">Name</p>
                      <div class="form-group">
                    <input type="text" disabled value="<?php echo e($user->name); ?>" class="form-control">
                  </div>
                   </div>
                   <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">Email</p>
                      <div class="form-group">
                    <input type="text" disabled value="<?php echo e($user->email); ?>" class="form-control">
                  </div>
                   </div>
                   <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">Mobile</p>
                      <div class="form-group">
                    <input type="text" disabled value="<?php if(isset($profile)): ?> <?php echo e($profile->Mobile); ?> <?php endif; ?>" class="form-control">
                  </div>
                   </div>
                   <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">Age</p>
                      <div class="form-group">
                    <input type="text" disabled class="form-control" value="<?php if(isset($profile)): ?> <?php echo e($profile->Age); ?> <?php endif; ?>">
                  </div>
                   </div>
                   <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">Gender</p>
                      <div class="form-group">
                    <input type="text" disabled class="form-control" value="<?php if(isset($profile)): ?> <?php echo e($profile->Gender); ?> <?php endif; ?>">
                  </div>
                   </div>
                   <div class="col-md-12">
                    <p style="font-weight: bold;margin-bottom: -13px;">Address</p>
                      <div class="form-group">
                    <input type="text" disabled class="form-control" value="<?php if(isset($address)): ?> <?php echo e($address->Address); ?> <?php endif; ?>">
                  </div>
                   </div>
                   <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">PinCode</p>
                      <div class="form-group">
                    <input type="text" disabled class="form-control" value="<?php if(isset($address)): ?> <?php echo e($address->PinCode); ?> <?php endif; ?>">
                  </div>
                </div>
                   <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">City</p>
                      <div class="form-group">
                    <input type="text" disabled class="form-control" value="<?php if(isset($address)): ?> <?php echo e($address->City); ?> <?php endif; ?>">
                  </div>
                   </div>
                  <div class="col-md-4">
                    <p style="font-weight: bold;margin-bottom: -13px;">State</p>
                      <div class="form-group">
                    <input type="text" disabled  class="form-control" value="<?php if(isset($address)): ?> <?php echo e($address->State); ?> <?php endif; ?>">
                  </div>
                </div>

                 </div>
                <!-- end content-->
              </div>
              <!--  end card  -->
            </div>
            <!-- end col-md-12 -->
          </div>
        </div>
          <!-- end row -->
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                  <div class="card-header card-header-primary card-header-icon" style="margin-top: -15px;">
                  <div style="background-color: #DE3743  ; padding: 10px; padding-left: 16px; padding-top:16px; border-radius: 3px;" style="width: 100%;">
                    <h4>Applied Jobs
                      </h4>
                  </div>

                </div>
               <div class="card-body">
                  <div class="toolbar">
                  </div>
                  <div class="material-datatables">
                    <table id="datatables" class="table table-no-bordered" cellspacing="0" width="100%" style="width:100%">
                      <thead>
                        <tr>
                          <th style="font-weight: bold;">#</th>
                          <th style="font-weight: bold;">JobTitle</th>
                          <th style="font-weight: bold;">AppliedEmail</th>
                          <th style="font-weight: bold;">AppliedMobile</th>
                          <th style="font-weight: bold;">AppliedDate</th>
                        </tr>
                      </thead>
                      <tbody>
                     <?php $i = 1; ?>
                     <?php $__currentLoopData = $jobapplied; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                          <td><?php echo e($i++); ?></td>
                          <td><?php echo e($row->JobTitle); ?></td>
                          <td><?php echo e($row->AppliedEmail); ?></td>
                          <td><?php echo e($row->AppliedMobile); ?></td>
                          <td><?php echo e($row->created_at); ?></td>

                          </td>
                        </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                  </div>
                </div>
              <!--  end card  -->
            </div>
            <!-- end col-md-12 -->
          </div>
        </div>
      </div>
</div>




<!--##### EMAIL SENDING POPUP MODEL STARTS  #####-->
<div class="modal" id="SndMail">
    <div class="modal-dialog">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header"  style="background-color: #DE3743; color:white;">
          <h4 class="modal-title" style="margin-top: -10px; margin-bottom: 10px;">Are You Sure Rechedule it ?</h4>
          <button type="button" class="close" data-dismiss="modal" style="color:white;">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
         
        </div>

        <!-- Modal footer   col-form-label -->
        <div style="padding-bottom: 50px;">
          <div class="col-sm-2"></div>
        </div>

      </div>
    </div>
  </div>
<!--##### EMAIL SENDING POPUP MODEL ENDS  #####-->




<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header"  style="background-color: #DE3743; color:white;">
        <h4 class="modal-title" style="margin-top: -10px; margin-bottom: 10px;">Are You Sure Delete It ?</h4>
        <button type="button" class="close" data-dismiss="modal" style="color:white;">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body" style="text-align: center; padding-top: 50px;">
        If you are delete it. you can't get it after
      </div>

      <!-- Modal footer -->
      <div class="row" style="padding-bottom: 50px;">
        <div class="col-sm-2"></div>
        <div class="col-sm-4">
          <form action="http://nbdigitech.com/AdminPanel/Admin/Appointments/Delete" method="post">
            <input type="hidden" name="_token" value="wjTOPSyjLK33UTY7iZOqyXatiiUYJFMcxIGxBj7A">
            <input type="hidden" id="delete_id" name="Delete">

          <button type="submit" class="btn btn-success" style="color:white; margin-right: 50px; width: 100%;">Yes</button>
          </form>
        </div>
        <div class="col-sm-4">
          <button type="button" class="btn btn-danger" data-dismiss="modal" style="color:white; width: 100%; background-color: #DE3743;">No</button>
        </div>
        <div class="col-sm-2"></div>
      </div>
    </div>
  </div>
</div>

<div class="modal" id="SndRemark">
        <div class="modal-dialog">
          <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header"  style="background-color: #DE3743; color:white;">
              <h4 class="modal-title" style="margin-top: -10px; margin-bottom: 10px;">Are You Sure Remark It ?</h4>
              <button type="button" class="close" data-dismiss="modal" style="color:white;">&times;</button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
              
              <div class="container">      
                    <form action="http://nbdigitech.com/AdminPanel/Admin/Appointment/EditRemarkSession" method="post">
                      <input type="hidden" name="_token" value="wjTOPSyjLK33UTY7iZOqyXatiiUYJFMcxIGxBj7A">
                        <input type="hidden" name="EditRemarkId" id="remId" />
                        <label class="">Description:</label>

                            <div class="form-group">
                                <textarea id="full-featured" class="form-control" rows="10" name="Remark" ></textarea>
                            </div>

                        <div class="form-group">
                            <input type="submit" class="btn btn-success" style="color:white; margin-right: 50px; box-shadow:none" value="SEND">
                        </div>


                    </form>
                </div>
            </div>

            <!-- Modal footer   col-form-label -->
            <div style="padding-bottom: 50px;">
              <div class="col-sm-2"></div>
            </div>

          </div>
        </div>
      </div>
    <!--##### MESSAGE SENDING POPUP MODEL ENDS  #####-->


    <!--##### APPOINTMENT DONE POPUP MODEL STARTS  #####-->
<div class="modal" id="SndDone"><div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header"  style="background-color: #DE3743; color:white;">
        <h4 class="modal-title" style="margin-top: -10px; margin-bottom: 10px;">Are You Sure Close This Appointment It ?</h4>
        <button type="button" class="close" data-dismiss="modal" style="color:white;">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body" style="text-align: center; padding-top: 50px;">
        If you are Close This Appointment. you can't get it after
      </div>

      <!-- Modal footer -->
      <div class="row" style="padding-bottom: 50px;">
        <div class="col-sm-2"></div>
        <div class="col-sm-4">
          <form action="http://nbdigitech.com/AdminPanel/Admin/Appointments/Appointment-Done" method="post">
            <input type="hidden" name="_token" value="wjTOPSyjLK33UTY7iZOqyXatiiUYJFMcxIGxBj7A">
            <input type="hidden" id="Appointment_Done" name="AppointmentDone">

          <button type="submit" class="btn btn-success" style="color:white; margin-right: 50px; width: 100%;">Yes</button>
          </form>
        </div>
        <div class="col-sm-4">
          <button type="button" class="btn btn-danger" data-dismiss="modal" style="color:white; width: 100%; background-color: red;">No</button>
        </div>
        <div class="col-sm-2"></div>
      </div>
    </div>
  </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\job_vacanc\resources\views/Admin/RegisteredUsers/CandidateDetails.blade.php ENDPATH**/ ?>