<?php $__env->startSection('headerid'); ?>
gradient
<?php $__env->stopSection(); ?>
<?php $__env->startSection('MainSection'); ?>
   <div class="alert-box success">Changes saved successfull !!!</div>
         <section>
            <div class="block no-padding  gray">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12">
                        <div class="inner2">
                           <div class="inner-title2">
                              <h3>Job Post</h3>
                              <span>Keep up to date with the latest news</span>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
<section>
      <div class="block">
         <div class="container">
            <div class="row">
               <div class="col-lg-8 column">
                  <div class="job-single-sec style3">
                     <div class="job-wide-devider">
                      
                        <div class="job-details">
                           <h2>Job Details</h2>
                           <br>
                           <h3>Job Title -</h3>
                           <p><?php echo e($data->JobTitle); ?> . </p>
                            <h3>Job Description -</h3>
                           <p><?php echo e($data->JobDescription); ?></p>
                           <ul>
                              <li>Qualification – <?php echo e($data->Qualification); ?></li>
                              <li>Experience - <?php echo e($data->Experience); ?></li>
                              <li>Skills - <?php echo e($data->Skills); ?></li>
                              
                           </ul><br>
                           <h3>Companty Info & Location</h3>
                           <p>Companany Name - <?php echo e($data->CompanyName); ?></p>
                           <p>Location - <?php echo e($data->City); ?></p>
                           <p></p>
                        </div>
                       
                      </div>
                  </div>
               </div>
               <div class="col-lg-4 column">
                  <div class="job-single-head style2">
                     <div class="job-thumb"> <img style="padding:10px; height: 70px; width: 100px;" src="<?php echo e(url('/')); ?>/public/assets/uploads/<?php echo e($data->Logo); ?>" alt=""  style="width: 100px" /> </div>
                     <div class="job-head-info">
                        <h4><?php echo e($data->CompanyName); ?></h4>
                        <p><i class="la la-phone"></i> <?php echo e($data->Mobile); ?></p>
                        <p><i class="la la-envelope-o"></i> <a href="/cdn-cgi/l/email-protection" class="__cf_email__"><?php echo e($data->Email); ?></a></p>
                     </div>
                     <div class="emply-btns">
                        <?php if(Auth::user()): ?>
                        <form action="<?php echo e(route('Job/Apply/Session')); ?>" method="post"><?php echo e(csrf_field()); ?>

                        <input type="hidden" name="JobPostId" value="<?php echo e($data->id); ?>">
                        <button  type="submit" style=" margin-top: 10px; width: 100%; padding:20px; border-radius: 50px; background: #fb236a;color:white;">APPLY NOW</button>
                        </form>
                        <?php else: ?>
                        <a href="#" class="signup-popup" style=" border:none; border-radius: 50px; background: #fb236a;color:white;">APPLY NOW</a>
                       <?php endif; ?>
                     </div>
                  </div><!-- Job Head -->
               </div>
            </div>
         </div>
      </div>
   </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\job_vacanc\resources\views/CompanyDetails.blade.php ENDPATH**/ ?>