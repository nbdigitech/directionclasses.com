<?php $__env->startSection('headerid'); ?>
gradient
<?php $__env->stopSection(); ?>
<?php $__env->startSection('MainSection'); ?>
<style type="text/css">
.card-head{
   text-align: left;
   cursor: none;
   background-color:#273244;
   color:white;
   padding:10px;
   margin-top: -10px;
   font-weight: normal;
}

#aler{
   width:400px;
   float: right;
}

#exampleModalLabel{
   text-align: center;
   margin-top: 60px;
}

#mydesign input, #select{
   margin-top: 30px;
}

#c{
   margin-right: 90px
}

#d{
   margin-right: 20px
}

#exampleModalLabel i{
   color:#F9D79F;
   font-weight: normal;
   font-size: 40px;
   border:2px solid #F9D79F;
   border-radius: 50px;
   padding:30px;
   font-weight: normal;
}

.modal-body h5{
   text-align: center;
}

.model-body .footer{
   text-align: center;
   margin-bottom: 30px
   margin-top:30px;
}

.footer button{
   padding-left: 30px; padding-right: 30px;
   padding-top:10px;
   padding-bottom:10px;

}

.modal-body h2{
   text-align: center;
   margin-top: 10px;
   font-weight: bold;
   color:#595959;
}

#list{
   font-size: 15px;
}

.input-group #input-group-addon{
   width: 40px;
}

.fa-mobile{
   font-size: 20px;
   margin-top: 10px;
}

.input-group textarea{
   padding-top: 20px;
}

.fa-location-arrow{
   margin-top:20px;
}

 .fa-phone{
   margin-top: 50px;
}
@media(max-width: 768px){
   #c{
   margin-right: 5px;
}
#aler{
   width:100%;
}
#d{
   margin-right: 5px
}

.emply-resume-list{
  text-align: center;
}

.emply-resume-thumb {
  margin-left:110px;
}
}
</style>
   <div class="alert-box success">Changes saved successfull !!!</div>
         <section>
            <div class="block no-padding  gray">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12">
                        <div class="inner2">
                           <div class="inner-title2">
                              <h3>Applied Candidates</h3>
                              <span>Candidate List who applied in your job post</span>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>

<section>
      <div class="block no-padding">
         <div class="container">
             <div class="row no-gape">
              
               <div class="col-lg-12 column">
                  <div class="padding-left">
                     <div class="emply-resume-sec">
                        <h3>Resume</h3>
                        <?php $__currentLoopData = $applied_candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="emply-resume-list">

                           <div class="row">
                              <div class="col-lg-9">
                              <div class="emply-resume-thumb">
                               
                              <img src="<?php echo e($row->pic); ?>" alt="" style="margin:auto" />
                            
                           </div>
                           <div class="emply-resume-info">
                            
                              <h3><?php echo e($row->name); ?></h3>
                              <span><i class="fa fa-envelope" style="color:gray; margin-right: 5px;"></i> Email : <i><?php echo e($row->AppliedEmail); ?></i></span>
                              <a href="tel:<?php echo e($row->AppliedMobile); ?>"><p><i class="la la-phone"></i>Mobile : <?php echo e($row->AppliedMobile); ?></p></a>
                           </div>
                           </div>
                           <div class="col-lg-2" style="padding-top: 30px;">
                           <div class="action-resume">
                              <div class="action-center" style="font-weight: bold;">
                                <?php echo e($row->JobTitle); ?>

                              </div>
                           </div>
                        </div>
                       <!--  <div class="col-lg-1" style="margin-top: 60px;">
                          <button type="button" data-toggle="modal" onclick="delete_function('<?php echo e($row->id); ?>')" data-target="#basicExampleModal" style="background: none;color:black; float: left; margin-top: -30px;"><i class="la la-trash-o" style="color:red; font-size: 25px;"></i> </button>
                        </div> -->
                           </div>
                        </div><!-- Emply List -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </div>
                  </div>
               </div>
             </div>
         </div>
      </div>
   </section>
   <div class="modal fade" id="basicExampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <p class="modal-title" id="exampleModalLabel"><i class="fa fa-exclamation"></i></p>
        <h2>Are you sure</h2>
        <h5>It will permanently deleted !</h5>
        <div class="footer"><br>
         <form method="post" action="<?php echo e(route('Profile/AppliedCandidates/Delete')); ?>">
            <?php echo e(csrf_field()); ?>

         <input type="hidden" name="Delete" id="delete_id">
      <button type="button" class="btn btn-danger" data-dismiss="modal" id="c">Cancel</button>
        <button type="submit" class="btn btn-primary" id="d" style="background: green; border:none">Yes Delete It!</button><br><br><br><br>
        </form>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
  function delete_function(id){
    document.getElementById('delete_id').value = id;
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\job_vacanc\resources\views/ApplidCandidates.blade.php ENDPATH**/ ?>