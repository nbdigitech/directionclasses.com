<?php $__env->startSection('headerid'); ?>
gradient
<?php $__env->stopSection(); ?>
<?php $__env->startSection('MainSection'); ?>
   <div class="alert-box success">Changes saved successfull !!!</div>
         <section>
            <div class="block no-padding  gray">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12">
                        <div class="inner2">
                           <div class="inner-title2">
                              <h3>Applied Candidates</h3>
                              <span>Candidate List who applied in your job post</span>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>

<section>
      <div class="block no-padding">
         <div class="container">
             <div class="row no-gape">
              
               <div class="col-lg-12 column">
                  <div class="padding-left">
                     <div class="emply-resume-sec">
                        <h3>Resume</h3>
                        <div class="emply-resume-list">
                           <div class="emply-resume-thumb">
                              <img src="images/resource/er1.jpg" alt="" />
                           </div>
                           <div class="emply-resume-info">
                              <h3><a href="#" title="">Ali TUFAN</a></h3>
                              <span><i>UX / UI Designer</i> at Atract Solutions</span>
                              <p><i class="la la-map-marker"></i>Istanbul / Turkey</p>
                           </div>
                           <div class="action-resume">
                              <div class="action-center">
                                 <span>Action <i class="la la-angle-down"></i></span>
                                 <ul>
                                    <li class="open-letter"><a href="#" title="">Cover Letter</a></li>
                                    <li><a href="#" title="">Download CV</a></li>
                                    <li><a href="#" title="">Linked-in Profile</a></li>
                                    <li class="open-contact"><a href="#" title="">Send a Message</a></li>
                                    <li><a href="#" title="">View Profile</a></li>
                                 </ul>
                              </div>
                           </div>
                           <div class="del-resume">
                              <a href="#" title=""><i class="la la-trash-o"></i></a>
                           </div>
                        </div><!-- Emply List -->
                        <div class="emply-resume-list">
                           <div class="emply-resume-thumb">
                              <img src="images/resource/er2.jpg" alt="" />
                           </div>
                           <div class="emply-resume-info">
                              <h3><a href="#" title="">Ali TUFAN</a></h3>
                              <span><i>UX / UI Designer</i> at Atract Solutions</span>
                              <p><i class="la la-map-marker"></i>Istanbul / Turkey</p>
                           </div>
                           <div class="action-resume">
                              <div class="action-center">
                                 <span>Action <i class="la la-angle-down"></i></span>
                                 <ul>
                                    <li class="open-letter"><a href="#" title="">Cover Letter</a></li>
                                    <li><a href="#" title="">Download CV</a></li>
                                    <li><a href="#" title="">Linked-in Profile</a></li>
                                    <li class="open-contact"><a href="#" title="">Send a Message</a></li>
                                    <li><a href="#" title="">View Profile</a></li>
                                 </ul>
                              </div>
                           </div>
                           <div class="del-resume">
                              <a href="#" title=""><i class="la la-trash-o"></i></a>
                           </div>
                        </div><!-- Emply List -->
                        <div class="emply-resume-list">
                           <div class="emply-resume-thumb">
                              <img src="images/resource/er3.jpg" alt="" />
                           </div>
                           <div class="emply-resume-info">
                              <h3><a href="#" title="">Ali TUFAN</a></h3>
                              <span><i>UX / UI Designer</i> at Atract Solutions</span>
                              <p><i class="la la-map-marker"></i>Istanbul / Turkey</p>
                           </div>
                           <div class="action-resume">
                              <div class="action-center">
                                 <span>Action <i class="la la-angle-down"></i></span>
                                 <ul>
                                    <li class="open-letter"><a href="#" title="">Cover Letter</a></li>
                                    <li><a href="#" title="">Download CV</a></li>
                                    <li><a href="#" title="">Linked-in Profile</a></li>
                                    <li class="open-contact"><a href="#" title="">Send a Message</a></li>
                                    <li><a href="#" title="">View Profile</a></li>
                                 </ul>
                              </div>
                           </div>
                           <div class="del-resume">
                              <a href="#" title=""><i class="la la-trash-o"></i></a>
                           </div>
                        </div><!-- Emply List -->
                        <div class="emply-resume-list">
                           <div class="emply-resume-thumb">
                              <img src="images/resource/er4.jpg" alt="" />
                           </div>
                           <div class="emply-resume-info">
                              <h3><a href="#" title="">Ali TUFAN</a></h3>
                              <span><i>UX / UI Designer</i> at Atract Solutions</span>
                              <p><i class="la la-map-marker"></i>Istanbul / Turkey</p>
                           </div>
                           <div class="action-resume">
                              <div class="action-center">
                                 <span>Action <i class="la la-angle-down"></i></span>
                                 <ul>
                                    <li class="open-letter"><a href="#" title="">Cover Letter</a></li>
                                    <li><a href="#" title="">Download CV</a></li>
                                    <li><a href="#" title="">Linked-in Profile</a></li>
                                    <li class="open-contact"><a href="#" title="">Send a Message</a></li>
                                    <li><a href="#" title="">View Profile</a></li>
                                 </ul>
                              </div>
                           </div>
                           <div class="del-resume">
                              <a href="#" title=""><i class="la la-trash-o"></i></a>
                           </div>
                        </div><!-- Emply List -->
                        <div class="emply-resume-list">
                           <div class="emply-resume-thumb">
                              <img src="images/resource/er5.jpg" alt="" />
                           </div>
                           <div class="emply-resume-info">
                              <h3><a href="#" title="">Ali TUFAN</a></h3>
                              <span><i>UX / UI Designer</i> at Atract Solutions</span>
                              <p><i class="la la-map-marker"></i>Istanbul / Turkey</p>
                           </div>
                           <div class="action-resume">
                              <div class="action-center">
                                 <span>Action <i class="la la-angle-down"></i></span>
                                 <ul>
                                    <li class="open-letter"><a href="#" title="">Cover Letter</a></li>
                                    <li><a href="#" title="">Download CV</a></li>
                                    <li><a href="#" title="">Linked-in Profile</a></li>
                                    <li class="open-contact"><a href="#" title="">Send a Message</a></li>
                                    <li><a href="#" title="">View Profile</a></li>
                                 </ul>
                              </div>
                           </div>
                           <div class="del-resume">
                              <a href="#" title=""><i class="la la-trash-o"></i></a>
                           </div>
                        </div><!-- Emply List -->
                        <div class="emply-resume-list">
                           <div class="emply-resume-thumb">
                              <img src="images/resource/er6.jpg" alt="" />
                           </div>
                           <div class="emply-resume-info">
                              <h3><a href="#" title="">Ali TUFAN</a></h3>
                              <span><i>UX / UI Designer</i> at Atract Solutions</span>
                              <p><i class="la la-map-marker"></i>Istanbul / Turkey</p>
                           </div>
                           <div class="action-resume">
                              <div class="action-center">
                                 <span>Action <i class="la la-angle-down"></i></span>
                                 <ul>
                                    <li class="open-letter"><a href="#" title="">Cover Letter</a></li>
                                    <li><a href="#" title="">Download CV</a></li>
                                    <li><a href="#" title="">Linked-in Profile</a></li>
                                    <li class="open-contact"><a href="#" title="">Send a Message</a></li>
                                    <li><a href="#" title="">View Profile</a></li>
                                 </ul>
                              </div>
                           </div>
                           <div class="del-resume">
                              <a href="#" title=""><i class="la la-trash-o"></i></a>
                           </div>
                        </div><!-- Emply List -->
                     </div>
                  </div>
               </div>
             </div>
         </div>
      </div>
   </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\job_vacancy\resources\views/ApplidCandidates.blade.php ENDPATH**/ ?>