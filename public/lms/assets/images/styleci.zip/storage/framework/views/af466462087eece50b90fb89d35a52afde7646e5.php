<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	
	<title>Job Portal</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="author" content="CreativeLayers">
	<link href="https://fonts.googleapis.com/css?family=Slabo+27px&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/public/assets/css/bootstrap-grid.css" />
	<link rel="stylesheet" href="<?php echo e(url('/')); ?>/public/assets/css/icons.css">
	<link rel="stylesheet" href="<?php echo e(url('/')); ?>/public/assets/css/animate.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/public/assets/css/style.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/public/assets/css/responsive.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/public/assets/css/chosen.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/public/assets/css/colors/colors.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/public/assets/css/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/public/assets/css/multistep.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/public/assets/css/c_style.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/public/assets/css/font-awesome.min.css" />
</head><?php /**PATH C:\xamp\htdocs\job_vacancy\resources\views/layouts/Header.blade.php ENDPATH**/ ?>