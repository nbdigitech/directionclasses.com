 <div class="responsive-header">
         <div class="responsive-menubar">
            <div class="res-logo"><a href="<?php echo e(route('Index')); ?>" style="color:white;font-size:30px">Job Vacancy</a></div>

             <?php if(Auth::user()): ?>
               	<div class="my-profiles-sec" style="margin-left: 20px;"><span><img src="<?php echo e(Auth::user()->pic); ?>" alt="" style="width: 50px;">  <i class="la la-bars"></i></span><nav></nav></div>
               <?php endif; ?>
             <?php if(!Auth::user()): ?>
            <div class="menu-resaction">
               <div class="res-openmenu"><img src="<?php echo e(url('/')); ?>/public/assets/images/icon.png" alt="jobs"> Menu</div>
               <div class="res-closemenu"><img src="<?php echo e(url('/')); ?>/public/assets/images/icon2.png" alt="jobs"> Close</div>
            </div>
            <?php endif; ?>
         </div>
         <div class="responsive-opensec">
               
            <div class="btn-extars">
               <?php if(Auth::user()): ?>
               <?php if(Auth::user()->role=='Employer'): ?>
               <a class="post-job-btn" href="<?php echo e(route('Profile/JobPost')); ?>"><i class="la la-plus"></i>Post Jobs</a>
               <?php endif; ?> <?php endif; ?>
               <ul class="account-btns">
                  <li class="signup-popup"><a href="#"><i class="la la-external-link-square"></i> Login</a></li>
               </ul>
            </div>
            <form class="res-search"><input type="text" placeholder="Job title, keywords or company name"><button type="submit"><i class="la la-search"></i></button></form>
            <div class="responsivemenu">
               <ul>

                  <li class="menu-item-has-children"><a href="<?php echo e(route('Index')); ?>">Home</a></li>
                  <li class="menu-item-has-children"><a href="<?php echo e(route('About')); ?>">About</a></li>
                  <li class="menu-item-has-children"><a href="<?php echo e(route('FindJob')); ?>">FindJob</a></li>
                  <li class="menu-item-has-children"><a href="<?php echo e(route('Contact')); ?>">Contact</a></li>
               </ul>
            </div>
         </div>
      </div>
      <header class="<?php echo $__env->yieldContent('headerid'); ?>"><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
         <div class="menu-sec">
            <div class="container">
               <div class="logo"><a href="<?php echo e(route('Index')); ?>" style="color:white;font-size:30px">Job Vacancy</a></div>

               <?php if(Auth::user()): ?>
               	<div class="my-profiles-sec" style="margin-left: 20px;"><span><img src="<?php echo e(Auth::user()->pic); ?>" alt="" style="width: 50px;">  <i class="la la-bars"></i></span><nav></nav></div>
               <?php endif; ?>
               <?php if(!Auth::user()): ?>
               <div class="btn-extars">
                  <ul class="account-btns">
                     <li class="signup-popup" style="margin-top: 4px;"><a href="#"><i class="la la-external-link-square"></i> Login</a></li>
                  </ul>
               </div>
               <?php endif; ?>
               <?php if(Auth::user()): ?>
               <?php if(Auth::user()->role=='Employer'): ?>
               <div class="btn-extars">
               <a href="<?php echo e(route('Profile/JobPost')); ?>" title="" class="post-job-btn"><i class="la la-plus"></i>Post Jobs</a>
               <?php endif; ?>
               <?php endif; ?>
            </div><!-- Btn Extras -->
               <nav>
                  <ul>
                     <li class="menu"><a href="<?php echo e(route('Index')); ?>">Home</a></li>
                     <li class="menu"><a href="<?php echo e(route('About')); ?>">About</a></li>
                     <li class="menu"><a href="<?php echo e(route('FindJob')); ?>">FindJob</a></li>
                     <li class="menu"><a href="<?php echo e(route('Contact')); ?>">Contact</a></li>
                  </ul>
               </nav>
            </div>
         </div>
      </header><?php /**PATH /home/glwsvozu/jobvacancy.app/resources/views/layouts/Navbar.blade.php ENDPATH**/ ?>