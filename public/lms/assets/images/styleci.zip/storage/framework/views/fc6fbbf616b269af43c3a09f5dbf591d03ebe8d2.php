<?php $__env->startSection('headerid'); ?>
gradient
<?php $__env->stopSection(); ?>
<?php $__env->startSection('MainSection'); ?>
   <div class="alert-box success">Changes saved successfull !!!</div>
         <section>
            <div class="block no-padding  gray">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12">
                        <div class="inner2">
                           <div class="inner-title2">
                              <h3>Profile</h3>
                              <span>Keep up to date with the latest news</span>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <section>
            <div class="block no-padding">
               <div class="container">
                  <div class="row no-gape">
                     <div class="col-lg-12 column">
                        <div class="padding-left">
                           <div class="contact-edit">
                              <div id="profile_update">
                                 <div id="header_profile">
                                    <h4>Update Profile</h4>
                                    <p><a href="#popup-optin">+</a></p>
                                 </div>
                                 <?php if($profile): ?>
                                 <div id="body_profile">
                                    <div class="row" style="color: gray;">
                                       <div class="col-sm-6">
                                          <h6> Name : <?php echo e($profile->Name); ?></h6>
                                          <h6> Email : <?php echo e($profile->Email); ?></h6>
                                          <h6> Mobile : <?php echo e($profile->Mobile); ?></h6>
                                       </div>
                                       <div class="col-sm-6">
                                          <h6> Age : <?php echo e($profile->Age); ?></h6>
                                          <h6> Gender : <?php echo e($profile->Gender); ?></h6>
                                       </div>
                                    </div>
                                 </div>
                                 <?php else: ?>
                                  <div id="body_profile">
                                    <h6>   No Item to Display</h6>
                                 </div>
                                 <?php endif; ?>
                                 <div class="bg-overlay" id="popup-optin" style="z-index: 2147483647;">
                                    <div class="subscribe-optin" style="text-transform: capitalize;">
                                       <div id="header_popup">Update Personal Details<a href="#" id="optin" style="color: rgb(19, 31, 113); font-size: 20px;">X</a></div>
                                       <div id="body_popup">
                                          <form action="<?php echo e(route('Profile/Store')); ?>" method="post">
                                             <?php echo e(csrf_field()); ?>

                                             <input type="hidden" name="UserId" value="<?php if(Auth::user()): ?><?php echo e(Auth::user()->id); ?><?php endif; ?>">
                                             <p style="margin-bottom: 10px; height: 20px;">Full Name</p>
                                             <input type="text" name="Name" required="" value="<?php if(Auth::user()): ?><?php echo e(Auth::user()->name); ?><?php endif; ?>" style="height: 40px; padding-left: 20px; font-size: 17px;">
                                             <p style="margin-bottom: 10px; height: 20px; margin-top: 20px; font-size: 17px;">Email Address</p>
                                             <input type="text" readonly name="Email" required="" value="<?php if(Auth::user()): ?><?php echo e(Auth::user()->email); ?><?php endif; ?>" style="height: 40px; padding-left: 20px; font-size: 17px;">
                                             <p style="margin-bottom: 10px; height: 20px; margin-top: 20px; font-size: 17px;">Mobile Number</p>
                                             <input type="text" name="Mobile" required="" value="<?php if($profile): ?><?php echo e($profile->Mobile); ?><?php endif; ?>" style="height: 40px; padding-left: 20px; font-size: 17px;">
                                             <p style="margin-bottom: 10px; height: 20px; margin-top: 20px; font-size: 17px;">Age</p>
                                             <input type="text" name="Age" required="" value="<?php if($profile): ?><?php echo e($profile->Age); ?><?php endif; ?>" style="height: 40px; padding-left: 20px; font-size: 17px;">
                                             <p style="margin-bottom: 10px; height: 20px; margin-top: 20px;">Gender</p>
                                             <div class="center-align"><input type="radio" name="Gender" id="size_1" value="Male" <?php if($profile): ?> <?php if($profile->Gender=='Male'): ?> checked <?php endif; ?> <?php endif; ?>><label for="size_1" style="width:200px">Male</label><input type="radio" <?php if($profile): ?> <?php if($profile->Gender=='Female'): ?> checked <?php endif; ?> <?php endif; ?> name="Gender" id="size_2" value="Female"><label for="size_2" style="width:200px">Female</label></div>
                                             <div class="row">
                                                <div class="col-sm-8"></div>
                                                <div class="col-sm-4"><button type="submit" style="background: rgb(16, 25, 93); margin-top: 20px; border: none; color: white; padding: 10px; width: 100%; border-radius: 2px;">Submit Now</button></div>
                                             </div>
                                          </form>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="contact-edit">
                              <div id="profile_update">
                                 <div id="header_profile">
                                    <h4>Update Address</h4>
                                    <p><a href="#popup-optin2">+</a></p>
                                 </div>
                                  <?php if($address): ?>
                                 <div id="body_profile">
                                    <div class="row" style="color: gray;">
                                       <div class="col-sm-6">
                                          <h6> Address : <?php echo e($address->Address); ?></h6>
                                          <h6> PinCode : <?php echo e($address->PinCode); ?></h6>
                                       </div>
                                       <div class="col-sm-6">
                                          <h6> City : <?php echo e($address->City); ?></h6>
                                          <h6> State : <?php echo e($address->State); ?></h6>
                                       </div>
                                    </div>
                                 </div>
                                 <?php else: ?>
                                  <div id="body_profile">
                                    <h6>   No Item to Display</h6>
                                 </div>
                                 <?php endif; ?>
                                 <div class="bg-overlay" id="popup-optin2" style="z-index: 2147483647;">
                                    <div class="subscribe-optin" style="text-transform: capitalize;">
                                       <div id="header_popup">Update Your Location<a href="#" id="optin" style="color: rgb(19, 31, 113); font-size: 20px;">X</a></div>
                                       <div id="body_popup">
                                          <form action="<?php echo e(route('Profile/Address/Store')); ?>" method="post">
                                             <?php echo e(csrf_field()); ?>

                                             <input type="hidden" name="UserId" value="<?php if(Auth::user()): ?><?php echo e(Auth::user()->id); ?><?php endif; ?>">
                                             <p style="margin-bottom: 10px; height: 20px;">Full Address</p>
                                             <input type="text" name="Address" required="" value="" style="height: 40px; padding-left: 20px; font-size: 17px;">
                                             <p style="margin-bottom: 10px; height: 20px; margin-top: 20px; font-size: 17px;">City</p>
                                             <input type="text" name="City" required="" value="" style="height: 40px; padding-left: 20px; font-size: 17px;">
                                             <p style="margin-bottom: 10px; height: 20px; margin-top: 20px; font-size: 17px;">State</p>
                                             <input type="text" name="State" required="" value="" style="height: 40px; padding-left: 20px; font-size: 17px;">
                                             <p style="margin-bottom: 10px; height: 20px; margin-top: 20px; font-size: 17px;">PinCode</p>
                                             <input type="text" name="PinCode" required="" value="" style="height: 40px; padding-left: 20px; font-size: 17px;">
                                             <div class="row">
                                                <div class="col-sm-8"></div>
                                                <div class="col-sm-4"><button type="submit" style="background: rgb(16, 25, 93); margin-top: 20px; border: none; color: white; padding: 10px; width: 100%; border-radius: 2px;">Submit Now</button></div>
                                             </div>
                                          </form>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="contact-edit">
                              <div id="profile_update">
                                 <div id="header_profile">
                                    <h4>Update Qualification</h4>
                                    <p><a href="#popup-optin3">+</a></p>
                                 </div>
                                  <?php if($ql): ?>
                                 <div id="body_profile">
                                    <div class="row" style="color: gray;">
                                       <div class="col-sm-6">
                                          <h6> Max Qualification : <?php echo e($ql->MaxQualification); ?></h6>
                                          <h6> Language : <?php echo e($ql->Language); ?></h6>
                                       </div>
                                    </div>
                                 </div>
                                 <?php else: ?>
                                  <div id="body_profile">
                                    <h6>   No Item to Display</h6>
                                 </div>
                                 <?php endif; ?>
                                 <div class="bg-overlay" id="popup-optin3" style="z-index: 2147483647;">
                                    <div class="subscribe-optin" style="text-transform: capitalize;">
                                       <div id="header_popup">Update Personal Details<a href="#" id="optin" style="color: rgb(19, 31, 113); font-size: 20px;">X</a></div>
                                       <div id="body_popup">
                                          <form action="<?php echo e(route('Profile/Qualification/Store')); ?>" method="post">
                                             <?php echo e(csrf_field()); ?>

                                             <p style="margin-bottom: 0px; height: 20px; margin-top: 20px;">Please Select Max Qualification : </p>
                                             <div class="row">
                                                <input type="hidden" name="UserId" value="<?php if(Auth::user()): ?><?php echo e(Auth::user()->id); ?><?php endif; ?>">
                                                <div class="col-lg-3 col-md-4 col-sm-6 col-6" style="padding:2px;"><input type="radio" name="Qualification" id="size_3" value="10th Pass"><label for="size_3" style="width: 100vh;">10th Pass</label></div>
                                                <div class="col-lg-3 col-md-4 col-sm-6 col-6" style="padding:2px;"><input type="radio" name="Qualification" id="size_4" value="12th Pass"><label for="size_4" style="width: 100vh;">12th Pass</label></div>
                                                <div class="col-lg-3 col-md-4 col-sm-6 col-6" style="padding:2px;"><input type="radio" name="Qualification" id="size_5" value="Graduate"><label for="size_5" style="width: 100vh;">Graduate</label></div>
                                                <div class="col-lg-3 col-md-4 col-sm-6 col-6" style="padding:2px;"><input type="radio" name="Qualification" id="size_6" value="Post Graduate"><label for="size_6" style="width: 100vh;">Post Graduate </label></div>
                                             </div>
                                             <div class="row">
                                                <p style="margin-top: 20px; margin-bottom: -10px; margin-left: 20px;">Select Your Language : </p>
                                             </div>
                                             <div class="row">
                                                <div class="col-lg-4 ol-md-4 col-sm-6 col-6" style="padding:2px"><input type="radio" name="Language" id="size_7" value="English"><label for="size_7" style="width: 100vh;">English</label></div>
                                                <div class="col-lg-4 ol-md-4 col-sm-6 col-6" style="padding:2px"><input type="radio" name="Language" id="size_8" value="Hindi"><label for="size_8" style="width:100vh;">Hindi</label></div>
                                             </div>
                                             <div class="row">
                                                <div class="col-sm-8"></div>
                                                <div class="col-sm-4"><button type="submit" style="background: rgb(16, 25, 93); margin-top: 20px; border: none; color: white; padding: 10px; width: 100%; border-radius: 2px;">Submit Now</button></div>
                                             </div>
                                          </form>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="contact-edit">
                              <div id="profile_update">
                                 <div id="header_profile">
                                    <h4>Other</h4>
                                    <p><a href="#popup-optin4">+</a></p>
                                 </div>
                                  <?php if($job): ?>
                                 <div id="body_profile">
                                    <div class="row" style="color: gray;">
                                       <div class="col-sm-12">
                                          <h6> Job Role : <?php echo e($job->JobRole); ?></h6>
                                       </div>
                                     
                                    </div>
                                 </div>
                                 <?php else: ?>
                                  <div id="body_profile">
                                    <h6>   No Item to Display</h6>
                                 </div>
                                 <?php endif; ?>
                                 <div class="bg-overlay" id="popup-optin4" style="z-index: 2147483647;">
                                    <div class="subscribe-optin" style="text-transform: capitalize;">
                                       <div id="header_popup">Update Personal Details<a href="#" id="optin" style="color: rgb(19, 31, 113); font-size: 20px;">X</a></div>
                                       <div id="body_popup">
                                          <form action="<?php echo e(route('Profile/JobRole/Store')); ?>" method="post">
                                             <p style="margin-bottom: 0px; height: 20px; margin-top: 20px;">Job Role : </p>
                                            <div class="row">
                                             <?php echo e(csrf_field()); ?>

                                                <input type="hidden" name="UserId" value="<?php if(Auth::user()): ?><?php echo e(Auth::user()->id); ?><?php endif; ?>">
                                                <div class="col-lg-3 col-md-4 col-sm-6 col-6" style="padding:2px"><input type="checkbox" name="JobRole[]" id="size_11" value="Website Designer"><label for="size_11" style="width: 100vh;">Website Designer</label></div>
                                                <div class="col-lg-3 col-md-4 col-sm-6 col-6" style="padding:2px"><input type="checkbox" name="JobRole[]" id="size_12" value="Web Developer"><label for="size_12" style="width: 100vh;">Web Developer</label></div>
                                                <div class="col-lg-3 col-md-4 col-sm-6 col-6" style="padding:2px"><input type="checkbox" name="JobRole[]" id="size_13" value="Content Writer"><label for="size_13" style="width: 100vh;">Content Writer</label></div>
                                                <div class="col-lg-3 col-md-4 col-sm-6 col-6" style="padding:2px"><input type="checkbox" name="JobRole[]" id="size_14" value="Digital Marketer"><label for="size_14" style="width: 100vh;">Digital Marketer </label></div>
                                                <div class="col-lg-3 col-md-4 col-sm-6 col-6" style="padding:2px"><input type="checkbox" name="JobRole[]" id="size_15" value="Blogger"><label for="size_15" style="width: 100vh;">Blogger</label></div>
                                                <div class="col-lg-3 col-md-4 col-sm-6 col-6" style="padding:2px"><input type="checkbox" name="JobRole[]" id="size_16" value="Hr Manager"><label for="size_16" style="width: 100vh;">Hr Manager</label></div>
                                                <div class="col-lg-3 col-md-4 col-sm-6 col-6" style="padding:2px"><input type="checkbox" name="JobRole[]" id="size_17" value="Software Engineer"><label for="size_17" style="width: 100vh;">Software Engineer </label></div>
                                                <div class="col-lg-3 col-md-4 col-sm-6 col-6" style="padding:2px"><input type="checkbox" name="JobRole[]" id="size_18" value="React Developer"><label for="size_18" style="width: 100vh;">React Developer</label></div>
                                                <div class="col-lg-3 col-md-4 col-sm-6 col-6" style="padding:2px"><input type="checkbox" name="JobRole[]" id="size_19" value="Laravel Developer"><label for="size_19" style="width: 100vh;">Laravel Developer</label></div>
                                                <div class="col-lg-3 col-md-4 col-sm-6 col-6" style="padding:2px"><input type="checkbox" name="JobRole[]" id="size_20" value="Nodejs Developer"><label for="size_20" style="width: 100vh;">Nodejs Developer</label></div>
                                                <div class="col-lg-3 col-md-4 col-sm-6 col-6" style="padding:2px"><input type="checkbox" name="JobRole[]" id="size_21" value="IOS Developer"><label for="size_21" style="width: 100vh;">IOS Developer </label></div>
                                                <div class="col-lg-3 col-md-4 col-sm-6 col-6" style="padding:2px"><input type="checkbox" name="JobRole[]" id="size_22" value="React Native"><label for="size_22" style="width: 100vh;">React Native </label></div>

                                             </div>
                                           
                                             <div class="row">
                                                <div class="col-sm-8"></div>
                                                <div class="col-sm-4"><button type="submit" style="background: rgb(16, 25, 93); margin-top: 20px; border: none; color: white; padding: 10px; width: 100%; border-radius: 2px;">Submit Now</button></div>
                                             </div>
                                          </form>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      </div>
   
   </div>
   <div>
      <div class="account-popup-area signin-popup-box">
         <div class="account-popup">
            <span class="close-popup"><i class="la la-close"></i></span>
            <h3>User Login</h3>
            <span>Click To Login With Demo User</span>
            <div class="select-user"><span>Candidate</span><span>Employer</span></div>
            <form>
               <div class="cfield"><input type="text" placeholder="Username"><i class="la la-user"></i></div>
               <div class="cfield"><input type="password" placeholder="********"><i class="la la-key"></i></div>
               <p class="remember-label"><input type="checkbox" name="cb" id="cb1"><label for="cb1">Remember me</label></p>
               <a href="/">Forgot Password?</a><button type="submit">Login</button>
            </form>
            <div class="extra-login">
               <span>Or</span>
               <div class="login-social"><a class="fb-login" href="/"><i class="fa fa-facebook"></i></a><a class="tw-login" href="/"><i class="fa fa-twitter"></i></a></div>
            </div>
         </div>
      </div>
      <div class="account-popup-area signup-popup-box">
         <div class="account-popup">
            <span class="close-popup"><i class="la la-close"></i></span>
            <h3>Sign Up</h3>
            <p style="margin-top: 20px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
            <form style="margin-top: -5px; margin-bottom: 30px;">
               <button type="button" style="background-color: rgb(255, 255, 255); display: inline-flex; align-items: center; color: rgba(0, 0, 0, 0.54); box-shadow: rgba(0, 0, 0, 0.24) 0px 2px 2px 0px, rgba(0, 0, 0, 0.24) 0px 0px 1px 0px; padding: 0px; border-radius: 2px; border: 1px solid transparent; font-size: 14px; font-weight: 500; font-family: Roboto, sans-serif;">
                  <div style="margin-right: 10px; background: rgb(255, 255, 255); padding: 10px; border-radius: 2px;">
                     <svg width="18" height="18" xmlns="http://www.w3.org/2000/svg">
                        <g fill="#000" fill-rule="evenodd">
                           <path d="M9 3.48c1.69 0 2.83.73 3.48 1.34l2.54-2.48C13.46.89 11.43 0 9 0 5.48 0 2.44 2.02.96 4.96l2.91 2.26C4.6 5.05 6.62 3.48 9 3.48z" fill="#EA4335"></path>
                           <path d="M17.64 9.2c0-.74-.06-1.28-.19-1.84H9v3.34h4.96c-.1.83-.64 2.08-1.84 2.92l2.84 2.2c1.7-1.57 2.68-3.88 2.68-6.62z" fill="#4285F4"></path>
                           <path d="M3.88 10.78A5.54 5.54 0 0 1 3.58 9c0-.62.11-1.22.29-1.78L.96 4.96A9.008 9.008 0 0 0 0 9c0 1.45.35 2.82.96 4.04l2.92-2.26z" fill="#FBBC05"></path>
                           <path d="M9 18c2.43 0 4.47-.8 5.96-2.18l-2.84-2.2c-.76.53-1.78.9-3.12.9-2.38 0-4.4-1.57-5.12-3.74L.97 13.04C2.45 15.98 5.48 18 9 18z" fill="#34A853"></path>
                           <path fill="none" d="M0 0h18v18H0z"></path>
                        </g>
                     </svg>
                  </div>
                  <span style="padding: 10px 10px 10px 0px; font-weight: 500;">LOGIN WITH GOOGLE</span>
               </button>
              
            </form>
         </div>
      </div>
<?php if(session()->has('success')): ?>
<div class="alert alert-success fixed-top" id="aler" role="alert" style="color:white;background: #3BC761;border:none;padding-top:20px; padding-bottom:20px;">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close" ><span aria-hidden="true">&times;</span></button>
  <strong style="color:white">Success!</strong> <?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\job_vacanc\resources\views/Profil.blade.php ENDPATH**/ ?>