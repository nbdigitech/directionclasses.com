<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
        'endpoint' => env('MAILGUN_ENDPOINT', 'api.mailgun.net'),
    ],

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'google' => [
    'client_id' => '252059010893-qptf8orifr9e3pjpuvnalbnqbrlbd24i.apps.googleusercontent.com',
    'client_secret' => 'qrglibMDLupvAL5ulZ23Vrj5',
    'redirect' => 'http://localhost/job_vacanc/callback/google',
    ],

    'linkedin' => [
        'client_id' => '815eb3o4s21ljd',
        'client_secret' => 'Evq0kJFLlFmpQ6w3',
        'redirect' => 'http://localhost/job_vacanc/Linkedin/Callback'
    ],


];
